# the comtypes.tools package

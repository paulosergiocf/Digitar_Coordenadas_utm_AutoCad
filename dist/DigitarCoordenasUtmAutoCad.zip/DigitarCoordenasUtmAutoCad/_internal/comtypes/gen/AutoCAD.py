from enum import IntFlag

import comtypes.gen._5B3245BE_661C_4324_BB55_3AD94EBBFDD7_0_1_0 as __wrapper_module__
from comtypes.gen._5B3245BE_661C_4324_BB55_3AD94EBBFDD7_0_1_0 import (
    acDegrees180, acTitleSuppressed, IAcadDimRadialLarge,
    AcadSubEntity, acAttachmentMiddle, acDimPrecisionSeven,
    AcadTextStyles, acCellStateFormatLocked, acAngular,
    acViewport3Above, acTitleVertRightLineWeight, acDimPrecisionFive,
    acLsNewViewport, acArrowArchTick, acTitleRowTextStyle,
    AcadEllipse, AcadLayer, acContentLayout, acBottomMask,
    acInsertUnitsUnitless, acOTStatic, acHeaderHorzBottomLineWeight,
    acSymInFront, acUnitVolume, acEdRepeatLastCommand, ac270degrees,
    acArrowsOnly, acPixels, acDemandLoadOnObjectDetect,
    AcadSubEntSolidNode, acHeaderVertInsideVisibility,
    AcadPolygonMesh, acDgnUnderlay, LONG_PTR, acUnknownDataType,
    ACADSECURITYPARAMS_SIGN_DATA, acHeaderHorzTopColor, ac2007_dxf,
    acHeight, acVp1_128in_1ft, _DAcadDocumentEvents, acEnglish,
    acLnWt035, acHatchLoopTypePolyline, AcadTextStyle,
    acEnableBackgroundColor, acUnitDistance, IAcadSectionTypeSettings,
    IAcadSubEntSolidEdge, acVp3_32in_1ft, ac1_4, AcadMLeaderStyle,
    acResbuf, acExtendNone, IAcadDimRotated, AcadDimArcLength,
    acDegrees60, IAcadViewports, acBlockSlot, AcadSolid,
    acCreaseByLevel, IAcad3DFace, acArrowSmall, ac1_20, acTurns,
    acAlignmentTopRight, acCellStateLinked, IAcadHyperlinks, acBuffer,
    IAcadMInsertBlock, acLnWt090, acAlignPntAcquisitionShiftToAcquire,
    IAcadPointCloudEx2, AcadLine, acScaleToFit, acTolerance,
    acDimLWindowsDesktop, AcadRevolvedSurface, IAcadGroups, acPoint2d,
    AcadGroups, acHeaderVertRightColor, acDataTypeAndFormat,
    AcadDimension, acVp1ft_1ft, acSqrtChord,
    acHeaderHorzTopVisibility, AcadSubEntSolidVertex, acOff,
    acArrowDatumBlank, acSplineLeader, acMtext,
    acAttachmentMiddleOfBottom, acDataVertInsideVisibility,
    acInsertUnitsLightYears, acCellTopGridLineWeight, IAcadUCS,
    acDwfUnderlay, acVertInside, acViewport4, acCellContentColor,
    acSectionSubItemkNone, acLnWt000, acInsertUnitsAstronomicalUnits,
    IAcadPreferencesProfiles, acLnWt053, acLnWt140, acCenterAlignment,
    acIntensity, acArc, IAcadDictionaries, acExtents, acR15_dwg,
    ac2000_dwg, acToolbarDockBottom, acPoint, acUnknown, acDate,
    acAllNormal, acUnitless, acMarginRight, IAcadMenuBar,
    acArrowOpen90, acVp8_1, acInsertUnitsMils, acAlignmentBottomLeft,
    acVp1_100, acGreen, IAcadRegisteredApplication, acRadians,
    acAllCellProperties, AcadMLeader, IAcadDimArcLength,
    acEnableSCMOptions, acSmooth, acHatchLoopTypeDefault,
    AcadPreferencesUser, acDataRowFillNone, IAcadAttributeReference,
    acCellRightGridColor, acArrowBoxBlank, acDataVertRightLineWeight,
    acIntensityEditableFlag, acDouble, AcadToolbars, acCellMarginLeft,
    acLong, AcadAttributeReference, VARIANT_BOOL, acEllipse, acRuled,
    acTitleRowFillNone, acDataHorzTopLineWeight, acLimits,
    AcadRegisteredApplication, acInsertUnitsGigameters, acLnWt080,
    acLnWt030, AcadSubEntSolidFace, acHorizontalAlignmentRight,
    AcadRegion, acDimFractionalStacked, acArrowOrigin2, acPenWidth140,
    acInsertUnitsHectometers, acPaletteBySession,
    IAcadRevolvedSurface, acCellAlign, IAcadLayouts,
    acProxyBoundingBox, acHorizontalAlignmentAligned, AcadTolerance,
    acDimOrdinate, acAlignmentMiddleRight, acRightToLeft,
    acAlignmentBottomRight, acUnknownRow, acCellBackgroundColor,
    acAttributeModeVerify, acDataHorzBottomColor, IAcadUtility,
    ac2010_Template, AcadFileDependencies, acR13_dxf, AcadPopupMenus,
    acInvalidGridLine, acMarginBottom, acTitleVertLeftVisibility,
    acPrinterNeverAlertLogOnce, acCellBottomGridColor,
    acVerticalAlignmentBaseline, acTitleRow, AcadIdPair,
    acToolbarDockTop, IAcadObjectEvents, acVp3_8in_1ft,
    AcadPreferencesSelection, IAcadBlocks,
    acHatchPatternTypeUserDefined, acWindow, AcadSelectionSet,
    acDragDoNotDisplay, acColorMethodByACI, AcadEntity, ac1_64in_1ft,
    acPolicyNamed, AcadText, AcadDatabasePreferences,
    acUpdateOptionUpdateFullSourceRange, acShadePlotAsDisplayed,
    acDimRadialLarge, IAcadMenuGroups, acSectionType3dSection,
    IAcadGeomapImage, AcadDimOrdinate, AcadPreferencesOpenSave,
    acHorizontalAlignmentFit, AcadDimRadial, ac1_10,
    acSectionSubItemVerticalLineBottom, acDimEngineering,
    acShadePlotRendered, AcadHelix, AcadPlotConfiguration,
    acColorMethodForeground, acSectionSubItemBackLine,
    acCellLeftVisibility, IAcad3DSolid, acPreferenceClassic,
    acMergeCellStyleConvertDuplicatesToOverrides, acLsLineType,
    acToolbarControl, acNative, acProxyShow, AcadGroup,
    acAttributeModeConstant, acExternalReference, IAcadLeader,
    acInsertUnitsMicroinches, acAttachmentPointBottomCenter,
    acTextFlagBackward, ac3_4in_1ft, acDragDisplayAutomatically,
    acConnectExtents, acPenWidthUnk, acVp1_64in_1ft,
    acDimPrecisionTwo, acArrowOpen30, acInsertUnitsFeet, acTolNone,
    acAlignmentTopLeft, acDimArchitecturalStacked, acMenuFileCompiled,
    acDegrees90, acDegrees090, acBestFit, acInsertUnitsPrompt,
    acVerticalAlignmentMiddle, acTitleRowColor, acTop,
    IAcadDatabasePreferences, AcadPlotConfigurations, AcadPdfUnderlay,
    acTitleRowTextHeight, acDimLineWithText, AcadPreferencesSystem,
    acProxyNotShow, acSectionSubItemBackLineBottom,
    acCastsAndReceivesShadows, acHeaderSuppressed, ACAD_ANGLE,
    AcadLeader, acClassification, acSectionType2dSection,
    acHorzBottom, acScientific, acArrowClosed, acLayout,
    ACAD_DISTANCE, acSymAbove, acCenterLine, acVp1_8in_1ft, acCyan,
    AcadMInsertBlock, acDimPrecisionZero, AcadPlot, acVp1_2,
    acAttachmentBottomOfTop, IAcadDimOrdinate, acDimPrecisionEight,
    acMergeCellStyleOverwriteDuplicates, acAttachmentBottomLine,
    acViewport3Left, acHeaderHorzInsideVisibility,
    AcadSectionSettings, acSectionSubItemSectionLineTop,
    IAcadPolyline, acSubDMesh, ac1_4in_1ft, AcadMText, IAcadDimStyles,
    acR15_dxf, acHorizontalAlignmentMiddle, acLnWt009, acLnWt040,
    acForExpression, acIntensities, acSubtraction,
    acHeaderVertLeftLineWeight, acPenWidth200, AcadPreferencesOutput,
    acAlignmentMiddle, ac2004_dwg, acTrueColor, AcadAcCmColor,
    acRaster, acSectionStatePlane, AcadPreferences, acForEditing,
    IAcadPopupMenus, AcadLayouts, AcadMLeaderLeader, AcadDwfUnderlay,
    ac1_16, acDimRadial, HRESULT, Acad3DSolid,
    acHeaderVertRightLineWeight, acTitleRowFillColor,
    acAlignmentProperty, acBottomRight, acHeaderRowFillNone,
    acAlignmentTopCenter, acHeaderHorzInsideLineWeight, acBottom,
    acPreDefinedGradient, IAcadMLeader, acDimWindowsDesktop,
    acTitleRowAlignment, IAcadGeoPositionMarker, acEnableSCM,
    acStraightLeader, acLeftAlignment, acUniform, ac2004_Template,
    acLnWt100, AcadSelectionSets, acAttachmentPointTopLeft, ac3dFace,
    acBlockContent, acInsertUnitsAutoAssign, acFlowDirBtoT,
    acInsertUnitsCentimeters, IAcadDimension, IAcadSection2, acHide,
    AcadExternalReference, acShape, acFractional,
    AcadPreferencesFiles, acSectionGenerationDestinationFile,
    acMLeader, acCellStateContentLocked, AcadDgnUnderlay, ac1_1,
    acByLayer, ac2000_Template, acVertCellMargin, AcadDocuments,
    acUseDefaultDrawingAreaShortCutMenu, acAlignmentLeft,
    IAcadMLeaderStyle, IAcadTextStyles, acIsoparms,
    acCellStateContentReadOnly, acHorizontalAlignmentLeft,
    IAcadDimAngular, IAcadSweptSurface, IAcadWipeout,
    acCellRightVisibility, acGroup, acBlockHexagon,
    acTableBottomToTop, acUnknownCell, AcadArc, acDataType,
    IAcadPreferencesDrafting, acSelectionSetAll, acXline,
    acTitleVertRightVisibility, acMLine, AcadLayerStateManager,
    acDemandLoadDisabled, acTableFlowDownOrUp, acMenuFileSource,
    acTitleHorzInsideVisibility, acConnectBase,
    acDataHorzInsideVisibility, acObjectId, acMergeAll,
    acDemandLoadEnabled, acNoDrawingAreaShortCutMenu,
    AcadSortentsTable, acBlockCell, acDataVertInsideColor,
    acDegreeMinuteSeconds, acDimArcLength, AcadNurbSurface,
    acAttachmentPointTopCenter, acContentColor, acVp1_10,
    acPolicyLegacyLegacy, acDimDiametric, acDataHorzInsideColor,
    AcadCircle, acLnWt070, AcadDimRotated, acIntensityRainbow,
    COMMETHOD, AcadUCSs, acDegrees270, ac1_50, IAcadRay,
    acAttributeModeMultipleLine, acOTLink, acArrowIntegral,
    AcadDatabase, AcadPointCloudEx, IAcadSubEntSolidNode,
    AcadRegisteredApplications, acNurbSurface, acLsColor,
    acCellMarginHorzSpacing, acLineNoArrow, AcadHatch, typelib_path,
    IAcadLoftedSurface, acHatch, IAcadArc,
    acUpdateOptionOverwriteFormatModifiedAfterUpdate, ac1_2in_1ft,
    acKeyboardEntryExceptScripts, acR12_dxf, acPolicyLegacyQuery,
    IAcadXline, acDataHorzBottomLineWeight, acLnWt106, IAcadSolid,
    IAcadSelectionSet, acSectionSubItemBackLineTop, acMenuSeparator,
    acFalse, acAttributeModeNormal, acArea, AcadObject,
    ACADSECURITYPARAMS_ADD_TIMESTAMP, AcadXRecord, acByStyle,
    acAlignmentBottomCenter, ac3_16in_1ft, acQuadSurfaceMesh,
    IAcadPoint, acNormal, acOQGraphics, acPViewport,
    acTitleVertLeftLineWeight, acAttribute, acMenuSubMenu, acSymNone,
    acAttachmentTopOfTop, acSolid, acSectionSubItemVerticalLineTop,
    acHatchPatternTypeCustomDefined, acSelectionSetWindow,
    acInsertUnitsYards, AcadSubDMeshVertex, acCW, acModelSpace,
    acPenWidth100, IAcadText, acApplied, acArrowDotSmall,
    IAcadFileDependency, AcadBlockReference, acDimPrecisionSix,
    acDragDisplayOnRequest, ac2_1, acDataHorzTopVisibility,
    acTextOnly, acInVisibleLeader, acTopToBottom, acTextCell,
    acPlotOrientationPortrait, acLnWt200, IAcadHelix,
    acSectionState2Volume, AcadTrace, ac180degrees, acEnter,
    acSectionTypeLiveSection, acEdSCM,
    acSectionGenerationDestinationReplaceBlock, AcadGeoPositionMarker,
    acHeaderVertLeftColor, acLnWt018, acAttributeModeLockPosition,
    acIntensityBlue, IAcadPlotConfiguration, acAttachmentCenter,
    IAcadSection, acSectionGenerationSourceAllObjects,
    acIntensityGrayscale, acGeneral, IAcadLine, acDataRowColor,
    DISPMETHOD, acPolyline, acIgnoreShadows, ac1_2, acTable,
    IAcadMLine, acCustomParameterization, acDimLFractional,
    acCellStateNone, IAcadDwfUnderlay, acTopCenter, acOQText,
    IAcadSummaryInfo, acSetDefaultFormat, acPenWidth035,
    acIntensityGreen, acActiveViewport, IAcadObject, acVp1_8,
    AcadDimStyles, ac1ft_1ft, acLnWtByLayer, acTableTopToBottom,
    IAcadExtrudedSurface, AcadPointCloud, IAcadSectionSettings,
    acMergeCellStyleNone, AcadDimAligned, acCellTopVisibility,
    acLeader, IAcadDimDiametric, IAcadToolbars, acInsertUnitsMeters,
    acVp1_30, acView, IAcadPointCloudEx, acArrowDefault,
    AcadModelSpace, acVp1_5, acEngineering, IAcadPopupMenu,
    IAcadPolyfaceMesh, acHeaderVertInsideColor, acGradientObject,
    acCellStateContentModified, acAlignPntAcquisitionAutomatic,
    acEndsNormal, IAcadEllipse, acDegrees15, acAttributeReference,
    acViewport2Horizontal, acCellTopGridColor, acDim3PointAngular,
    Library, acMoveTextAddLeader, acUnitAngle, acNoneCrease,
    acAlignmentFit, IAcadPreferencesSelection, ac8_1, IAcadTrace,
    acNotStacked, acVertLeft, AcadOle, acInsertUnitsNanometers,
    acAttachmentPointTopRight, acLsLineWeight, acCubicSurfaceMesh,
    acCircle, AcadApplication, acTitleHorzTopColor, BSTR,
    acFontRegular, acZoomScaledAbsolute, acTrace, acMiddleCenter,
    acHorizontal, AcadDimRadialLarge, AcadState, acRightAlignment,
    acSectionGenerationSourceSelectedObjects, acIntersection,
    acRegion, IDispatch, acBottomCenter, acVp2_1, IAcadMenuGroup,
    acCellContentTypeField, IAcadSectionTypeSettings2,
    acCellMarginRight, acMTextContent, acScale, acHatchObject, acSCM,
    acVp1_16in_1ft, acOCS, IAcadPlot, AcadPoint, acPolicyLegacy,
    AcadViewport, AcadRasterImage, acInsertUnitsAngstroms,
    acSectionState2Boundary, acBezierSurfaceMesh, acR18_dxf,
    acSectionState2Slice, IAcadFileDependencies, acBlockUserDefined,
    IAcadShape, IAcadPaperSpace, acDemandLoadEnabledWithCopy,
    IAcadPreferencesOpenSave, acUnion, acSplineNoArrow,
    acPrinterAlwaysAlert, IAcadNurbSurface, acCellTextStyle,
    acTitleVertInsideLineWeight, acHeaderVertInsideLineWeight,
    acHatchLoopTypeDerived, acUnder, acViewport3Vertical,
    acSecondExtensionLine, acVp10_1, acKeyboardRunningObjSnap,
    acPolylineLight, acScanColor, acAttachmentPointMiddleCenter,
    acAttachmentBottomOfBottom, acUniformParam, acMarginTop,
    acUnitArea, ac1_8, AcadLineType, acInsertUnitsUSSurveyYard,
    IAcadSubEntity, IAcadSecurityParams, acVp1_4in_1ft, acDataRow,
    AcadLayout, acPaletteByDrawing, AcadDim3PointAngular,
    AcadPolyline, acUpdateSourceFromData, IAcadShadowDisplay,
    acIntensityRed, AcadUtility, IAcadSortentsTable,
    acHeaderRowFillColor, acCellBackgroundFillNone, acCastsShadows,
    acPaperSpace, acTextHeight, IAcadPreferences, acByColor,
    acPenWidth025, acPreserveMtextFormat, ac2013_Template,
    acKeyboardEntry, acShadePlotWireframe, ac2007_Template,
    acHorzInside, acHeaderRowColor, acLock, acLnWtByLwDefault,
    acVp1_1, acLnWt013, ACAD_LTYPE, acDimLScientific, AcadViewports,
    acArrowUserDefined, acColorMethodByLayer, acInvalidCellProperty,
    acShadePlotHidden, acDimLDecimal, AcadPopupMenuItem,
    acVp1_2in_1ft, ac100_1, acR13_dwg, acMergeCellStyleCopyDuplicates,
    acPlotOrientationLandscape, acDegrees30, acFontBold, AcadUCS,
    acCellRightGridLineWeight, acVp3_4in_1ft, acAlwaysCrease,
    AcadSectionTypeSettings, IAcadMLeaderLeader,
    acGridLineStyleDouble, acDemanLoadDisable, acPrinterNeverAlert,
    acFlowDirection, AcadPreferencesProfiles, IAcadApplication,
    acLnWt015, acLineSpacingStyleExactly, acBlue, AcadGeomapImage,
    ac3dPolyline, acMarginLeft, acFullPreview, acDiagonal,
    acAttributeModeInvisible, acLsPlotStyle, acCellMarginTop,
    acContentProperties, acInsertUnitsParsecs, acVp1_32in_1ft,
    acIgnoreMtextFormat, acNoneContent, acDegreesUnknown, AcadSpline,
    AcadBlock, acArrowDot, acDimLArchitectural, IAcadSelectionSets,
    acToolbarButton, acR18_Template, acMiddleRight, IAcadModelSpace,
    acVpScaleToFit, acAlwaysRightReadingAngle, IAcadSubEntSolidFace,
    acHorzCellMargin, IAcadRegion, acInsertUnitsMiles,
    acSectionSubItemSectionLineBottom, acOTEmbedded, AcadDimAngular,
    acSplineWithArrow, acDimPrecisionThree, acVp6in_1ft,
    IAcadAttribute, acSimple3DPoly, kInheritCellFormat, IAcadDimStyle,
    acCellStateFormatReadOnly, acAttachmentAllLine, IAcadHyperlink,
    AcadSweptSurface, acHeaderRowAlignment,
    acAttachmentBottomOfTopLine, acCubicSpline3DPoly,
    acSelectionSetPrevious, ac3_8in_1ft, acUpdateOptionNone,
    acBottomLeft, AcadToolbar, ac10_1, IAcadMText, acHorzTop,
    AcadExtrudedSurface, acTitleVertRightColor, acCellTextHeight,
    AcadPreferencesDrafting, IAcadState, IAcadToolbarItem,
    AcadPreferencesDisplay, acHeaderVertRightVisibility, acVp1_40,
    acSelectionSetLast, acObjectColor, ac2013_dwg, acCCW, acLnWt050,
    acSimpleMesh, acTitleHorzBottomLineWeight, acMagenta, acTolTop,
    IAcadMaterials, acDataRowTextStyle, ac1_128in_1ft,
    acAlignmentAligned, acDimAligned, acNorm,
    acAttachmentPointBottomLeft, acDegreesHorz, acDataRowDataType,
    AcadMaterials, acHatchLoopTypeExternal, acBlockCircle,
    acArrowDotBlank, acNoUnits, acCellContentLayoutStackedHorizontal,
    acDemandLoadCmdInvoke, acSectionSubItemSectionLine,
    acDataRowTextHeight, acUseDraftAngles, acInsertUnitsInches,
    AcadLoftedSurface, AcadDictionaries, acR14_dwg, acUCS,
    acTextStyle, AcadLineTypes, AcadMenuGroup, acTitleHorzInsideColor,
    acTurnHeight, acFit, acAttachmentVertical, acPolicyNewLegacy,
    dispid, AcadLWPolyline, AcadFileDependency, acVp1in_1ft,
    ac1in_1ft, acRotation, AcadSubDMeshFace, AcadAttribute,
    acLeftMask, acHatchStyleOuter, acAlignmentMiddleLeft,
    acControlVertices, acInsertUnitsMicrons, Acad3DPolyline, AcadRay,
    AcadSection, acVp1_4, IAcadSubDMeshFace, acTopRight, acTolBottom,
    AcadBlocks, AcadTable, acTableSelectCrossing, ac2000_dxf,
    acLnWt025, acMin, IAcadPlotConfigurations, acTitleHorzBottomColor,
    AcadSubEntSolidEdge, acArrowBoxFilled, acByBlock, IAcadPViewport,
    AcadDimStyle, acDataVertRightColor, IAcadLWPolyline,
    acCellDataType, acPenWidth018, acDataHorzBottomVisibility,
    acArrowOpen, acDimAngular, acNoOverrides, acMiddleLeft,
    acTextAndArrows, acTitleRowDataType, VARIANT, acRay, acDistance,
    acRed, acZoomScaledRelative, acDimDecimal, AcadSubDMesh,
    acDimPrecisionOne, AcadSurface, acTolBasic,
    acVerticalAlignmentBottom, _check_version, acDimArchitectural,
    acDrawLeaderTailFirst, ACAD_NULL, acPartialMenuGroup,
    AcadTableStyle, IAcadDimRadial, acVp1_20,
    IAcadDynamicBlockReferenceProperty, IAcadPreferencesUser,
    AcadPlaneSurface, ac90degrees, acCellLeftGridColor, Acad3DFace,
    acTextFlagUpsideDown, acToolbarFloating, acDegreesAny,
    acDrawContentFirst, acOverSecondExtension, acOQLineArt,
    acOverFirstExtension, ac1_100, ACAD_NOUNITS, acTolLimits,
    acDataVertLeftColor, acInsertUnitsUSSurveyFeet, acTopMask,
    acSelectionSetFence, acAttributeModePreset, acReceivesShadows,
    acHatchStyleNormal, acInsertAngle, acGridLineStyleSingle,
    acAttachmentHorizontal, acHorizontalAlignmentCenter,
    acOQHighPhoto, acPenWidth050, acFirstNormal,
    acInsertUnitsUSSurveyInch, acArrowClosedBlank,
    acUpdateDataFromSource, IAcadSubEntSolidVertex, IAcadTableStyle,
    ac2004_dxf, ACADSECURITYPARAMS_ENCRYPT_DATA, acColorMethodByRGB,
    acDisplayDCS, IAcadGroup, acBlockBox, acInsertUnitsUSSurveyMile,
    acDataHorzTopColor, acHeaderHorzTopLineWeight, ac4_1,
    acAttachmentPointBottomRight, acCellContentLayoutStackedVertical,
    acWorld, acCellContentLayoutFlow, IAcadBlockReference,
    IAcadTolerance, acArrowOrigin, acCellLeftGridLineWeight,
    acTableFlowLeft, acCenterNone, acViewport3Horizontal,
    acPartialPreview, acAttachmentPointMiddleRight, ac0degrees,
    AcadWipeout, IAcadLineTypes, AcadLayers, acDrawLeaderFirst,
    IAcadEntity, AcadHyperlinks, acBackgroundColor, IAcadDictionary,
    IAcadSpline, acVp1_50, acOutside, ac3in_1ft,
    acTitleVertInsideVisibility, acHeaderHorzInsideColor, AcadView,
    acTolDeviation, acObject, acAttachmentPointMiddleLeft, IAcadLayer,
    acHeaderRow, kFormatOptionNone, acArrowOblique,
    acToolbarDockRight, ac3_32in_1ft, acMenuItem, ac2010_dwg,
    acCellBottomGridLineWeight, acShow, acPdfUnderlay, AcadPaperSpace,
    acTableFlowRight, acTitleHorzTopVisibility, acText, IAcadMaterial,
    acQuadSpline3DPoly, acR18_dwg, acFontBoldItalic,
    ACADSECURITYPARAMS_ENCRYPT_PROPS, acHorzCentered, acZero,
    acOQPhoto, IAcadLineType, acPrinterAlertOnce, acTolSymmetrical,
    acHeaderRowTextStyle, IAcadLayerStateManager,
    acMergeCellStyleIgnoreNewStyles, IAcadSectionManager, acElevation,
    acHorizontalAngle, acExtendOtherEntity, AcadPopupMenu, acVp1_16,
    acLsFrozen, ACADSECURITYPARAMS_ALGID_RC4, acString, acPenWidth070,
    IAcadView, acArrowNone, AcadMenuBar,
    acSectionGenerationDestinationNewBlock, AcadDocument,
    AcadDimDiametric, acRepeatLastCommand, acOPQLowGraphics, CoClass,
    acLnWt020, acAny, acViewport3Right, acAlignmentMiddleCenter,
    acColorMethodByBlock, acBottomToTop, AcadSectionManager,
    ac6in_1ft, IAcadLayers, acLnWt158, AcadMaterial, acToolbarFlyout,
    acDataVertRightVisibility, IAcadBlock, acLnWt060, acDimFractional,
    acHeaderHorzBottomVisibility, IAcadRasterImage, acDegrees45,
    ac1_32in_1ft, acSectionStateBoundary, acLastNormal, AcadXline,
    acPaperSpaceDCS, acCenterMark, acQuadSplinePoly,
    acCubicSplinePoly, acSectionStateVolume, ac3dSolid,
    acVerticalAlignmentTop, IAcadTable, acDataHorzInsideLineWeight,
    acRightMask, acDimRotated, IAcadPointCloud, acLine,
    acDataVertLeftLineWeight, IAcadExternalReference,
    acSelectionSetWindowPolygon, acVpCustomScale, IAcadViewport,
    IAcadDocuments, IAcad3DPolyline, ac1_40, acYellow,
    acTitleHorzBottomVisibility, acFitCurvePoly, acExtendThisEntity,
    acMInsertBlock, acSectionState2Plane, IAcadDim3PointAngular,
    acInches, AcadViews, acGrads, acLsAll,
    AcadDynamicBlockReferenceProperty, acParseOptionNone,
    IAcadSubDMeshVertex, acSelectionSetCrossing, acRGB,
    acAlignmentRight, IAcadDimAligned, acCellMarginVertSpacing,
    acTopLeft, acTitleVertInsideColor, IAcadPreferencesSystem,
    acMoveTextNoLeader, ACAD_LAYER, GUID, acHatchLoopTypeTextbox,
    AcadHyperlink, acZoomScaledRelativePSpace, acLnWt005,
    acViewport2Vertical, kCellOptionNone, ac1_16in_1ft,
    IAcadSubDMeshEdge, acLnWtByBlock, acOPQHighGraphics,
    acDimScientific, acPolicyLegacyDefault,
    acHeaderVertLeftVisibility, acDataVertInsideLineWeight,
    acPolicyNewDefault, acBlockImperial, ACAD_POINT,
    acTitleVertLeftColor, AcadPolyfaceMesh, acDimLEngineering,
    acLsPlot, acVertRight, acArchitectural, acInsertUnitsMillimeters,
    acPolymesh, acR14_dxf, acVertCentered, ac2007_dwg,
    IAcadPopupMenuItem, acCellContentTypeBlock, acHeaderRowTextHeight,
    acArrowDatumFilled, ac2013_dxf, acTitleHorzTopLineWeight,
    acLineWithArrow, acSpline, acLnWt120, acDataRowAlignment,
    ac2010_dxf, acWhite, acPenWidth013, acCellContentTypeValue,
    acViewport3Below, acLsOn, acAutoScale,
    IAcadRegisteredApplications, acPoint3d, acHatchStyleIgnore,
    _midlSAFEARRAY, acFontItalic, IAcadDatabase, acToolbarDockLeft,
    acMillimeters, AcadDictionary, AcadMLine, IAcadViews,
    IAcadAcCmColor, acLsNone, acVp3_16in_1ft, acTableSelectWindow,
    acHeaderRowDataType, acUseMaximumPrecision,
    acCellBottomVisibility, acTolMiddle, AcadToolbarItem, acDegrees,
    IAcadSurface, acPolyfaceMesh, acNormals, acCellContentTypeUnknown,
    _DAcadApplicationEvents, IAcadPreferencesOutput, acDecimal,
    acLineSpacingStyleAtLeast, acFirstExtensionLine,
    acVp1and1_2in_1ft, acVp4_1, ac1_30, IAcadXRecord, AcadShape,
    acDataVertLeftVisibility, acBlockTriangle, IAcadHatch,
    IAcadToolbar, acTrue, acLnWt211, acAlignmentCenter, acChord,
    acCellStateFormatModified, acDisplay, acBitProperties,
    acSelectionSetCrossingPolygon, acAllViewports, acBlockReference,
    acUserDefinedGradient, acOn, acDataRowFillColor, _lcid,
    IAcadSubDMesh, IAcadIdPair, acInsertUnitsKilometers, acDegrees000,
    IAcadLayout, helpstring, AcadSummaryInfo, acOPQMonochrome,
    IAcadPreferencesDisplay, acDrawLeaderHeadFirst,
    acPreferenceCustom, acLsLocked, acToolbarSeparator,
    acAttachmentLinedCenter, acInsertUnitsDecameters,
    AcadSubDMeshEdge, acLeftToRight, AcadSecurityParams,
    acUpdateOptionOverwriteContentModifiedAfterUpdate,
    acTitleHorzInsideLineWeight, acDimPrecisionFour, acR15_Template,
    acAbove, ac1_5, IUnknown, acMetric, IAcadPreferencesFiles,
    AcadMenuGroups, acHatchPatternTypePreDefined, IAcadPlaneSurface,
    acCellMarginBottom, acVp100_1, acExtendBoth, IAcadCircle,
    IAcadOle, acUpdateOptionIncludeXrefs, acSimplePoly, acIsolines,
    IAcadUCSs, acMax, acBaseMenuGroup, IAcadUnderlay,
    acHeaderHorzBottomColor, IAcadTextStyle, acAttachmentMiddleOfTop,
    IAcadDocument, acInsertUnitsDecimeters, ac1_8in_1ft, acJIS,
    acVp3in_1ft, IAcadPolygonMesh, acDefaultUnits, acDataFormat,
    AcadPViewport
)


class AcPlotScale(IntFlag):
    acScaleToFit = 0
    ac1_128in_1ft = 1
    ac1_64in_1ft = 2
    ac1_32in_1ft = 3
    ac1_16in_1ft = 4
    ac3_32in_1ft = 5
    ac1_8in_1ft = 6
    ac3_16in_1ft = 7
    ac1_4in_1ft = 8
    ac3_8in_1ft = 9
    ac1_2in_1ft = 10
    ac3_4in_1ft = 11
    ac1in_1ft = 12
    ac3in_1ft = 13
    ac6in_1ft = 14
    ac1ft_1ft = 15
    ac1_1 = 16
    ac1_2 = 17
    ac1_4 = 18
    ac1_5 = 19
    ac1_8 = 20
    ac1_10 = 21
    ac1_16 = 22
    ac1_20 = 23
    ac1_30 = 24
    ac1_40 = 25
    ac1_50 = 26
    ac1_100 = 27
    ac2_1 = 28
    ac4_1 = 29
    ac8_1 = 30
    ac10_1 = 31
    ac100_1 = 32


class AcDataLinkUpdateOption(IntFlag):
    acUpdateOptionNone = 0
    acUpdateOptionOverwriteContentModifiedAfterUpdate = 131072
    acUpdateOptionOverwriteFormatModifiedAfterUpdate = 262144
    acUpdateOptionUpdateFullSourceRange = 524288
    acUpdateOptionIncludeXrefs = 1048576


class AcWindowState(IntFlag):
    acNorm = 1
    acMin = 2
    acMax = 3


class AcDrawingAreaShortCutMenu(IntFlag):
    acNoDrawingAreaShortCutMenu = 0
    acUseDefaultDrawingAreaShortCutMenu = 1


class AcOlePlotQuality(IntFlag):
    acOPQMonochrome = 0
    acOPQLowGraphics = 1
    acOPQHighGraphics = 2


class AcExtendOption(IntFlag):
    acExtendNone = 0
    acExtendThisEntity = 1
    acExtendOtherEntity = 2
    acExtendBoth = 3


class AcLineWeight(IntFlag):
    acLnWt000 = 0
    acLnWt005 = 5
    acLnWt009 = 9
    acLnWt013 = 13
    acLnWt015 = 15
    acLnWt018 = 18
    acLnWt020 = 20
    acLnWt025 = 25
    acLnWt030 = 30
    acLnWt035 = 35
    acLnWt040 = 40
    acLnWt050 = 50
    acLnWt053 = 53
    acLnWt060 = 60
    acLnWt070 = 70
    acLnWt080 = 80
    acLnWt090 = 90
    acLnWt100 = 100
    acLnWt106 = 106
    acLnWt120 = 120
    acLnWt140 = 140
    acLnWt158 = 158
    acLnWt200 = 200
    acLnWt211 = 211
    acLnWtByLayer = -1
    acLnWtByBlock = -2
    acLnWtByLwDefault = -3


class AcColor(IntFlag):
    acByBlock = 0
    acRed = 1
    acYellow = 2
    acGreen = 3
    acCyan = 4
    acBlue = 5
    acMagenta = 6
    acWhite = 7
    acByLayer = 256


class AcPointCloudExStylizationType(IntFlag):
    acRGB = 0
    acObject = 1
    acNormals = 2
    acIntensities = 3
    acElevation = 4
    acClassification = 5


class AcPatternType(IntFlag):
    acHatchPatternTypeUserDefined = 0
    acHatchPatternTypePreDefined = 1
    acHatchPatternTypeCustomDefined = 2


class AcISOPenWidth(IntFlag):
    acPenWidth013 = 13
    acPenWidth018 = 18
    acPenWidth025 = 25
    acPenWidth035 = 35
    acPenWidth050 = 50
    acPenWidth070 = 70
    acPenWidth100 = 100
    acPenWidth140 = 140
    acPenWidth200 = 200
    acPenWidthUnk = -1


class AcHatchStyle(IntFlag):
    acHatchStyleNormal = 0
    acHatchStyleOuter = 1
    acHatchStyleIgnore = 2


class AcLoopType(IntFlag):
    acHatchLoopTypeDefault = 0
    acHatchLoopTypeExternal = 1
    acHatchLoopTypePolyline = 2
    acHatchLoopTypeDerived = 4
    acHatchLoopTypeTextbox = 8


class AcHatchObjectType(IntFlag):
    acHatchObject = 0
    acGradientObject = 1


class AcGradientPatternType(IntFlag):
    acPreDefinedGradient = 0
    acUserDefinedGradient = 1


class AcCellProperty(IntFlag):
    acInvalidCellProperty = 0
    acLock = 1
    acDataType = 2
    acDataFormat = 4
    acRotation = 8
    acScale = 16
    acAlignmentProperty = 32
    acContentColor = 64
    acBackgroundColor = 128
    acTextStyle = 256
    acTextHeight = 512
    acMarginLeft = 1024
    acMarginTop = 2048
    acMarginRight = 4096
    acMarginBottom = 8192
    acEnableBackgroundColor = 16384
    acAutoScale = 32768
    acMergeAll = 65536
    acFlowDirBtoT = 131072
    acContentLayout = 262144
    acDataTypeAndFormat = 6
    acContentProperties = 33662
    acBitProperties = 245760
    acAllCellProperties = 524287


class AcWireframeType(IntFlag):
    acIsolines = 0
    acIsoparms = 1


class AcLoadPalette(IntFlag):
    acPaletteByDrawing = 0
    acPaletteBySession = 1


class AcInsertUnits(IntFlag):
    acInsertUnitsUnitless = 0
    acInsertUnitsInches = 1
    acInsertUnitsFeet = 2
    acInsertUnitsMiles = 3
    acInsertUnitsMillimeters = 4
    acInsertUnitsCentimeters = 5
    acInsertUnitsMeters = 6
    acInsertUnitsKilometers = 7
    acInsertUnitsMicroinches = 8
    acInsertUnitsMils = 9
    acInsertUnitsYards = 10
    acInsertUnitsAngstroms = 11
    acInsertUnitsNanometers = 12
    acInsertUnitsMicrons = 13
    acInsertUnitsDecimeters = 14
    acInsertUnitsDecameters = 15
    acInsertUnitsHectometers = 16
    acInsertUnitsGigameters = 17
    acInsertUnitsAstronomicalUnits = 18
    acInsertUnitsLightYears = 19
    acInsertUnitsParsecs = 20
    acInsertUnitsUSSurveyFeet = 21
    acInsertUnitsUSSurveyInch = 22
    acInsertUnitsUSSurveyYard = 23
    acInsertUnitsUSSurveyMile = 24


class AcUnderlayLayerOverrideType(IntFlag):
    acNoOverrides = 0
    acApplied = 1


class AcAttachmentPoint(IntFlag):
    acAttachmentPointTopLeft = 1
    acAttachmentPointTopCenter = 2
    acAttachmentPointTopRight = 3
    acAttachmentPointMiddleLeft = 4
    acAttachmentPointMiddleCenter = 5
    acAttachmentPointMiddleRight = 6
    acAttachmentPointBottomLeft = 7
    acAttachmentPointBottomCenter = 8
    acAttachmentPointBottomRight = 9


class AcDrawingDirection(IntFlag):
    acLeftToRight = 1
    acRightToLeft = 2
    acTopToBottom = 3
    acBottomToTop = 4
    acByStyle = 5


class AcLineSpacingStyle(IntFlag):
    acLineSpacingStyleAtLeast = 1
    acLineSpacingStyleExactly = 2


class AcSelectType(IntFlag):
    acTableSelectWindow = 1
    acTableSelectCrossing = 2


class AcPointCloudStylizationType(IntFlag):
    acScanColor = 0
    acObjectColor = 1
    acNormal = 2
    acIntensity = 3


class AcOleType(IntFlag):
    acOTLink = 1
    acOTEmbedded = 2
    acOTStatic = 3


class AcInsertUnitsAction(IntFlag):
    acInsertUnitsPrompt = 0
    acInsertUnitsAutoAssign = 1


class AcDimVerticalJustification(IntFlag):
    acVertCentered = 0
    acAbove = 1
    acOutside = 2
    acJIS = 3
    acUnder = 4


class AcDimPrecision(IntFlag):
    acDimPrecisionZero = 0
    acDimPrecisionOne = 1
    acDimPrecisionTwo = 2
    acDimPrecisionThree = 3
    acDimPrecisionFour = 4
    acDimPrecisionFive = 5
    acDimPrecisionSix = 6
    acDimPrecisionSeven = 7
    acDimPrecisionEight = 8


class AcDimTextMovement(IntFlag):
    acDimLineWithText = 0
    acMoveTextAddLeader = 1
    acMoveTextNoLeader = 2


class AcDimToleranceMethod(IntFlag):
    acTolNone = 0
    acTolSymmetrical = 1
    acTolDeviation = 2
    acTolLimits = 3
    acTolBasic = 4


class AcDimToleranceJustify(IntFlag):
    acTolBottom = 0
    acTolMiddle = 1
    acTolTop = 2


class AcDimUnits(IntFlag):
    acDimScientific = 1
    acDimDecimal = 2
    acDimEngineering = 3
    acDimArchitecturalStacked = 4
    acDimFractionalStacked = 5
    acDimArchitectural = 6
    acDimFractional = 7
    acDimWindowsDesktop = 8


class AcDimFit(IntFlag):
    acTextAndArrows = 0
    acArrowsOnly = 1
    acTextOnly = 2
    acBestFit = 3


class AcDimFractionType(IntFlag):
    acHorizontal = 0
    acDiagonal = 1
    acNotStacked = 2


class AcDimHorizontalJustification(IntFlag):
    acHorzCentered = 0
    acFirstExtensionLine = 1
    acSecondExtensionLine = 2
    acOverFirstExtension = 3
    acOverSecondExtension = 4


class AcDimLUnits(IntFlag):
    acDimLScientific = 1
    acDimLDecimal = 2
    acDimLEngineering = 3
    acDimLArchitectural = 4
    acDimLFractional = 5
    acDimLWindowsDesktop = 6


class AcDimArrowheadType(IntFlag):
    acArrowDefault = 0
    acArrowClosedBlank = 1
    acArrowClosed = 2
    acArrowDot = 3
    acArrowArchTick = 4
    acArrowOblique = 5
    acArrowOpen = 6
    acArrowOrigin = 7
    acArrowOrigin2 = 8
    acArrowOpen90 = 9
    acArrowOpen30 = 10
    acArrowDotSmall = 11
    acArrowDotBlank = 12
    acArrowSmall = 13
    acArrowBoxBlank = 14
    acArrowBoxFilled = 15
    acArrowDatumBlank = 16
    acArrowDatumFilled = 17
    acArrowIntegral = 18
    acArrowNone = 19
    acArrowUserDefined = 20


class AcTableStyleOverrides(IntFlag):
    acTitleSuppressed = 1
    acHeaderSuppressed = 2
    acFlowDirection = 3
    acHorzCellMargin = 4
    acVertCellMargin = 5
    acTitleRowColor = 6
    acHeaderRowColor = 7
    acDataRowColor = 8
    acTitleRowFillNone = 9
    acHeaderRowFillNone = 10
    acDataRowFillNone = 11
    acTitleRowFillColor = 12
    acHeaderRowFillColor = 13
    acDataRowFillColor = 14
    acTitleRowAlignment = 15
    acHeaderRowAlignment = 16
    acDataRowAlignment = 17
    acTitleRowTextStyle = 18
    acHeaderRowTextStyle = 19
    acDataRowTextStyle = 20
    acTitleRowTextHeight = 21
    acHeaderRowTextHeight = 22
    acDataRowTextHeight = 23
    acTitleRowDataType = 24
    acHeaderRowDataType = 25
    acDataRowDataType = 26
    acTitleHorzTopColor = 40
    acTitleHorzInsideColor = 41
    acTitleHorzBottomColor = 42
    acTitleVertLeftColor = 43
    acTitleVertInsideColor = 44
    acTitleVertRightColor = 45
    acHeaderHorzTopColor = 46
    acHeaderHorzInsideColor = 47
    acHeaderHorzBottomColor = 48
    acHeaderVertLeftColor = 49
    acHeaderVertInsideColor = 50
    acHeaderVertRightColor = 51
    acDataHorzTopColor = 52
    acDataHorzInsideColor = 53
    acDataHorzBottomColor = 54
    acDataVertLeftColor = 55
    acDataVertInsideColor = 56
    acDataVertRightColor = 57
    acTitleHorzTopLineWeight = 70
    acTitleHorzInsideLineWeight = 71
    acTitleHorzBottomLineWeight = 72
    acTitleVertLeftLineWeight = 73
    acTitleVertInsideLineWeight = 74
    acTitleVertRightLineWeight = 75
    acHeaderHorzTopLineWeight = 76
    acHeaderHorzInsideLineWeight = 77
    acHeaderHorzBottomLineWeight = 78
    acHeaderVertLeftLineWeight = 79
    acHeaderVertInsideLineWeight = 80
    acHeaderVertRightLineWeight = 81
    acDataHorzTopLineWeight = 82
    acDataHorzInsideLineWeight = 83
    acDataHorzBottomLineWeight = 84
    acDataVertLeftLineWeight = 85
    acDataVertInsideLineWeight = 86
    acDataVertRightLineWeight = 87
    acTitleHorzTopVisibility = 100
    acTitleHorzInsideVisibility = 101
    acTitleHorzBottomVisibility = 102
    acTitleVertLeftVisibility = 103
    acTitleVertInsideVisibility = 104
    acTitleVertRightVisibility = 105
    acHeaderHorzTopVisibility = 106
    acHeaderHorzInsideVisibility = 107
    acHeaderHorzBottomVisibility = 108
    acHeaderVertLeftVisibility = 109
    acHeaderVertInsideVisibility = 110
    acHeaderVertRightVisibility = 111
    acDataHorzTopVisibility = 112
    acDataHorzInsideVisibility = 113
    acDataHorzBottomVisibility = 114
    acDataVertLeftVisibility = 115
    acDataVertInsideVisibility = 116
    acDataVertRightVisibility = 117
    acCellAlign = 130
    acCellBackgroundFillNone = 131
    acCellBackgroundColor = 132
    acCellContentColor = 133
    acCellTextStyle = 134
    acCellTextHeight = 135
    acCellTopGridColor = 136
    acCellRightGridColor = 137
    acCellBottomGridColor = 138
    acCellLeftGridColor = 139
    acCellTopGridLineWeight = 140
    acCellRightGridLineWeight = 141
    acCellBottomGridLineWeight = 142
    acCellLeftGridLineWeight = 143
    acCellTopVisibility = 144
    acCellRightVisibility = 145
    acCellBottomVisibility = 146
    acCellLeftVisibility = 147
    acCellDataType = 148


class AcPointCloudIntensityStyle(IntFlag):
    acIntensityGrayscale = 0
    acIntensityRainbow = 1
    acIntensityRed = 2
    acIntensityGreen = 3
    acIntensityBlue = 4
    acIntensityEditableFlag = 5


class AcPlotType(IntFlag):
    acDisplay = 0
    acExtents = 1
    acLimits = 2
    acView = 3
    acWindow = 4
    acLayout = 5


class AcTextFontStyle(IntFlag):
    acFontRegular = 0
    acFontItalic = 1
    acFontBold = 2
    acFontBoldItalic = 3


class AcCellState(IntFlag):
    acCellStateNone = 0
    acCellStateContentLocked = 1
    acCellStateContentReadOnly = 2
    acCellStateFormatLocked = 4
    acCellStateFormatReadOnly = 8
    acCellStateLinked = 16
    acCellStateContentModified = 32
    acCellStateFormatModified = 64


class AcMenuGroupType(IntFlag):
    acBaseMenuGroup = 0
    acPartialMenuGroup = 1


class AcMenuFileType(IntFlag):
    acMenuFileCompiled = 0
    acMenuFileSource = 1


class AcLayerStateMask(IntFlag):
    acLsNone = 0
    acLsOn = 1
    acLsFrozen = 2
    acLsLocked = 4
    acLsPlot = 8
    acLsNewViewport = 16
    acLsColor = 32
    acLsLineType = 64
    acLsLineWeight = 128
    acLsPlotStyle = 256
    acLsAll = 65535


class AcAlignmentPointAcquisition(IntFlag):
    acAlignPntAcquisitionAutomatic = 0
    acAlignPntAcquisitionShiftToAcquire = 1


class AcPlotRotation(IntFlag):
    ac0degrees = 0
    ac90degrees = 1
    ac180degrees = 2
    ac270degrees = 3


class AcPlotPolicy(IntFlag):
    acPolicyNamed = 0
    acPolicyLegacy = 1


class AcSectionGeneration(IntFlag):
    acSectionGenerationSourceAllObjects = 1
    acSectionGenerationSourceSelectedObjects = 2
    acSectionGenerationDestinationNewBlock = 16
    acSectionGenerationDestinationReplaceBlock = 32
    acSectionGenerationDestinationFile = 64


class AcDrawingAreaSCMDefault(IntFlag):
    acRepeatLastCommand = 0
    acSCM = 1


class AcGridLineStyle(IntFlag):
    acGridLineStyleSingle = 1
    acGridLineStyleDouble = 2


class AcDataLinkUpdateDirection(IntFlag):
    acUpdateDataFromSource = 1
    acUpdateSourceFromData = 2


class AcDynamicBlockReferencePropertyUnitsType(IntFlag):
    acNoUnits = 0
    acAngular = 1
    acDistance = 2
    acArea = 3


class AcLoftedSurfaceNormalType(IntFlag):
    acRuled = 0
    acSmooth = 1
    acFirstNormal = 2
    acLastNormal = 3
    acEndsNormal = 4
    acAllNormal = 5
    acUseDraftAngles = 6


class AcDrawingAreaSCMEdit(IntFlag):
    acEdRepeatLastCommand = 0
    acEdSCM = 1


class AcDrawingAreaSCMCommand(IntFlag):
    acEnter = 0
    acEnableSCMOptions = 1
    acEnableSCM = 2


class AcAlignment(IntFlag):
    acAlignmentLeft = 0
    acAlignmentCenter = 1
    acAlignmentRight = 2
    acAlignmentAligned = 3
    acAlignmentMiddle = 4
    acAlignmentFit = 5
    acAlignmentTopLeft = 6
    acAlignmentTopCenter = 7
    acAlignmentTopRight = 8
    acAlignmentMiddleLeft = 9
    acAlignmentMiddleCenter = 10
    acAlignmentMiddleRight = 11
    acAlignmentBottomLeft = 12
    acAlignmentBottomCenter = 13
    acAlignmentBottomRight = 14


class AcCellContentType(IntFlag):
    acCellContentTypeUnknown = 0
    acCellContentTypeValue = 1
    acCellContentTypeField = 2
    acCellContentTypeBlock = 4


class AcAttributeMode(IntFlag):
    acAttributeModeNormal = 0
    acAttributeModeInvisible = 1
    acAttributeModeConstant = 2
    acAttributeModeVerify = 4
    acAttributeModePreset = 8
    acAttributeModeLockPosition = 16
    acAttributeModeMultipleLine = 32


class AcLeaderType(IntFlag):
    acLineNoArrow = 0
    acSplineNoArrow = 1
    acLineWithArrow = 2
    acSplineWithArrow = 3


class AcBlockScaling(IntFlag):
    acAny = 0
    acUniform = 1


class AcTextAttachmentType(IntFlag):
    acAttachmentTopOfTop = 0
    acAttachmentMiddleOfTop = 1
    acAttachmentBottomOfTop = 2
    acAttachmentBottomOfTopLine = 3
    acAttachmentMiddle = 4
    acAttachmentMiddleOfBottom = 5
    acAttachmentBottomOfBottom = 6
    acAttachmentBottomLine = 7
    acAttachmentAllLine = 8


class AcShadowDisplayType(IntFlag):
    acCastsAndReceivesShadows = 0
    acCastsShadows = 1
    acReceivesShadows = 2
    acIgnoreShadows = 3


class AcCellOption(IntFlag):
    kCellOptionNone = 0
    kInheritCellFormat = 1


class AcMLeaderType(IntFlag):
    acStraightLeader = 1
    acSplineLeader = 2
    acInVisibleLeader = 0


class AcTextAngleType(IntFlag):
    acInsertAngle = 0
    acHorizontalAngle = 1
    acAlwaysRightReadingAngle = 2


class AcShadePlot(IntFlag):
    acShadePlotAsDisplayed = 0
    acShadePlotWireframe = 1
    acShadePlotHidden = 2
    acShadePlotRendered = 3


class AcMLeaderContentType(IntFlag):
    acNoneContent = 0
    acBlockContent = 1
    acMTextContent = 2


class AcValueDataType(IntFlag):
    acUnknownDataType = 0
    acLong = 1
    acDouble = 2
    acString = 4
    acDate = 8
    acPoint2d = 16
    acPoint3d = 32
    acObjectId = 64
    acBuffer = 128
    acResbuf = 256
    acGeneral = 512


class AcPolymeshType(IntFlag):
    acSimpleMesh = 0
    acQuadSurfaceMesh = 5
    acCubicSurfaceMesh = 6
    acBezierSurfaceMesh = 8


class AcTableDirection(IntFlag):
    acTableTopToBottom = 0
    acTableBottomToTop = 1


class AcCellAlignment(IntFlag):
    acTopLeft = 1
    acTopCenter = 2
    acTopRight = 3
    acMiddleLeft = 4
    acMiddleCenter = 5
    acMiddleRight = 6
    acBottomLeft = 7
    acBottomCenter = 8
    acBottomRight = 9


class AcSectionSubItem(IntFlag):
    acSectionSubItemkNone = 0
    acSectionSubItemSectionLine = 1
    acSectionSubItemSectionLineTop = 2
    acSectionSubItemSectionLineBottom = 4
    acSectionSubItemBackLine = 8
    acSectionSubItemBackLineTop = 16
    acSectionSubItemBackLineBottom = 32
    acSectionSubItemVerticalLineTop = 64
    acSectionSubItemVerticalLineBottom = 128


class AcDimCenterType(IntFlag):
    acCenterMark = 0
    acCenterLine = 1
    acCenterNone = 2


class AcCellContentLayout(IntFlag):
    acCellContentLayoutFlow = 1
    acCellContentLayoutStackedHorizontal = 2
    acCellContentLayoutStackedVertical = 4


class AcTextAlignmentType(IntFlag):
    acLeftAlignment = 0
    acCenterAlignment = 1
    acRightAlignment = 2


class AcRowType(IntFlag):
    acUnknownRow = 0
    acDataRow = 1
    acTitleRow = 2
    acHeaderRow = 4


class AcColorMethod(IntFlag):
    acColorMethodByLayer = 192
    acColorMethodByBlock = 193
    acColorMethodByRGB = 194
    acColorMethodByACI = 195
    acColorMethodForeground = 197


class AcBooleanType(IntFlag):
    acUnion = 0
    acIntersection = 1
    acSubtraction = 2


class AcBlockConnectionType(IntFlag):
    acConnectExtents = 0
    acConnectBase = 1


class AcKeyboardAccelerator(IntFlag):
    acPreferenceClassic = 0
    acPreferenceCustom = 1


class AcKeyboardPriority(IntFlag):
    acKeyboardRunningObjSnap = 0
    acKeyboardEntry = 1
    acKeyboardEntryExceptScripts = 2


class AcMLineJustification(IntFlag):
    acTop = 0
    acZero = 1
    acBottom = 2


class AcMenuItemType(IntFlag):
    acMenuItem = 0
    acMenuSeparator = 1
    acMenuSubMenu = 2


class AcPredefBlockType(IntFlag):
    acBlockImperial = 0
    acBlockSlot = 1
    acBlockCircle = 2
    acBlockBox = 3
    acBlockHexagon = 4
    acBlockTriangle = 5
    acBlockUserDefined = 6


class AcSelect(IntFlag):
    acSelectionSetWindow = 0
    acSelectionSetCrossing = 1
    acSelectionSetFence = 2
    acSelectionSetPrevious = 3
    acSelectionSetLast = 4
    acSelectionSetAll = 5
    acSelectionSetWindowPolygon = 6
    acSelectionSetCrossingPolygon = 7


class AcDrawLeaderOrderType(IntFlag):
    acDrawLeaderHeadFirst = 0
    acDrawLeaderTailFirst = 1


class AcValueUnitType(IntFlag):
    acUnitless = 0
    acUnitDistance = 1
    acUnitAngle = 2
    acUnitArea = 4
    acUnitVolume = 8


class AcPolylineType(IntFlag):
    acSimplePoly = 0
    acFitCurvePoly = 1
    acQuadSplinePoly = 2
    acCubicSplinePoly = 3


class AcDrawMLeaderOrderType(IntFlag):
    acDrawContentFirst = 0
    acDrawLeaderFirst = 1


class AcSplineKnotParameterizationType(IntFlag):
    acChord = 0
    acSqrtChord = 1
    acUniformParam = 2
    acCustomParameterization = 15


class AcHorizontalAlignment(IntFlag):
    acHorizontalAlignmentLeft = 0
    acHorizontalAlignmentCenter = 1
    acHorizontalAlignmentRight = 2
    acHorizontalAlignmentAligned = 3
    acHorizontalAlignmentMiddle = 4
    acHorizontalAlignmentFit = 5


class AcVerticalAlignment(IntFlag):
    acVerticalAlignmentBaseline = 0
    acVerticalAlignmentBottom = 1
    acVerticalAlignmentMiddle = 2
    acVerticalAlignmentTop = 3


class AcXRefDemandLoad(IntFlag):
    acDemandLoadDisabled = 0
    acDemandLoadEnabled = 1
    acDemandLoadEnabledWithCopy = 2


class AcARXDemandLoad(IntFlag):
    acDemanLoadDisable = 0
    acDemandLoadOnObjectDetect = 1
    acDemandLoadCmdInvoke = 2


class AcProxyImage(IntFlag):
    acProxyNotShow = 0
    acProxyShow = 1
    acProxyBoundingBox = 2


class AcSaveAsType(IntFlag):
    acUnknown = -1
    acR12_dxf = 1
    acR13_dwg = 4
    acR13_dxf = 5
    acR14_dwg = 8
    acR14_dxf = 9
    ac2000_dwg = 12
    ac2000_dxf = 13
    ac2000_Template = 14
    ac2004_dwg = 24
    ac2004_dxf = 25
    ac2004_Template = 26
    ac2007_dwg = 36
    ac2007_dxf = 37
    ac2007_Template = 38
    ac2010_dwg = 48
    ac2010_dxf = 49
    ac2010_Template = 50
    ac2013_dwg = 60
    ac2013_dxf = 61
    ac2013_Template = 62
    acNative = 60
    acR15_dwg = 12
    acR15_dxf = 13
    acR15_Template = 14
    acR18_dwg = 24
    acR18_dxf = 25
    acR18_Template = 26


class AcSegmentAngleType(IntFlag):
    acDegreesAny = 0
    acDegrees15 = 1
    acDegrees30 = 2
    acDegrees45 = 3
    acDegrees60 = 4
    acDegrees90 = 6
    acDegreesHorz = 12


class AcSectionState(IntFlag):
    acSectionStatePlane = 1
    acSectionStateBoundary = 2
    acSectionStateVolume = 4


class AcVerticalTextAttachmentType(IntFlag):
    acAttachmentCenter = 0
    acAttachmentLinedCenter = 1


class AcSectionState2(IntFlag):
    acSectionState2Plane = 1
    acSectionState2Slice = 2
    acSectionState2Boundary = 4
    acSectionState2Volume = 8


class AcSectionType(IntFlag):
    acSectionTypeLiveSection = 1
    acSectionType2dSection = 2
    acSectionType3dSection = 4


class AcSplineFrameType(IntFlag):
    acShow = 0
    acHide = 1


class AcHelixConstrainType(IntFlag):
    acTurnHeight = 0
    acTurns = 1
    acHeight = 2


class AcHelixTwistType(IntFlag):
    acCCW = 0
    acCW = 1


class AcRotationAngle(IntFlag):
    acDegreesUnknown = -1
    acDegrees000 = 0
    acDegrees090 = 1
    acDegrees180 = 2
    acDegrees270 = 3


class AcTextAttachmentDirection(IntFlag):
    acAttachmentHorizontal = 0
    acAttachmentVertical = 1


class AcMeshCreaseType(IntFlag):
    acNoneCrease = 0
    acAlwaysCrease = 1
    acCreaseByLevel = 2


class AcParseOption(IntFlag):
    acParseOptionNone = 0
    acSetDefaultFormat = 1
    acPreserveMtextFormat = 2


class AcGridLineType(IntFlag):
    acInvalidGridLine = 0
    acHorzTop = 1
    acHorzInside = 2
    acHorzBottom = 4
    acVertLeft = 8
    acVertInside = 16
    acVertRight = 32


class AcFormatOption(IntFlag):
    kFormatOptionNone = 0
    acForEditing = 1
    acForExpression = 2
    acUseMaximumPrecision = 4
    acIgnoreMtextFormat = 8


class AcSplineMethodType(IntFlag):
    acFit = 0
    acControlVertices = 1


class AcCellType(IntFlag):
    acUnknownCell = 0
    acTextCell = 1
    acBlockCell = 2


class AcAngleUnits(IntFlag):
    acDegrees = 0
    acDegreeMinuteSeconds = 1
    acGrads = 2
    acRadians = 3


class AcCellEdgeMask(IntFlag):
    acTopMask = 1
    acRightMask = 2
    acBottomMask = 4
    acLeftMask = 8


class Ac3DPolylineType(IntFlag):
    acSimple3DPoly = 0
    acQuadSpline3DPoly = 1
    acCubicSpline3DPoly = 2


class AcCellMargin(IntFlag):
    acCellMarginTop = 1
    acCellMarginLeft = 2
    acCellMarginBottom = 4
    acCellMarginRight = 8
    acCellMarginHorzSpacing = 16
    acCellMarginVertSpacing = 32


class AcMergeCellStyleOption(IntFlag):
    acMergeCellStyleNone = 0
    acMergeCellStyleCopyDuplicates = 1
    acMergeCellStyleOverwriteDuplicates = 2
    acMergeCellStyleConvertDuplicatesToOverrides = 4
    acMergeCellStyleIgnoreNewStyles = 8


class AcTableFlowDirection(IntFlag):
    acTableFlowRight = 1
    acTableFlowDownOrUp = 2
    acTableFlowLeft = 4


class AcPointCloudColorType(IntFlag):
    acTrueColor = 0
    acByColor = 1


class AcToolbarItemType(IntFlag):
    acToolbarButton = 0
    acToolbarSeparator = 1
    acToolbarControl = 2
    acToolbarFlyout = 3


class AcActiveSpace(IntFlag):
    acPaperSpace = 0
    acModelSpace = 1


class AcRegenType(IntFlag):
    acActiveViewport = 0
    acAllViewports = 1


class AcDimArcLengthSymbol(IntFlag):
    acSymInFront = 0
    acSymAbove = 1
    acSymNone = 2


class AcBoolean(IntFlag):
    acFalse = 0
    acTrue = 1


class AcPreviewMode(IntFlag):
    acPartialPreview = 0
    acFullPreview = 1


class AcViewportSplitType(IntFlag):
    acViewport2Horizontal = 0
    acViewport2Vertical = 1
    acViewport3Left = 2
    acViewport3Right = 3
    acViewport3Horizontal = 4
    acViewport3Vertical = 5
    acViewport3Above = 6
    acViewport3Below = 7
    acViewport4 = 8


class AcOnOff(IntFlag):
    acOff = 0
    acOn = 1


class AcPlotOrientation(IntFlag):
    acPlotOrientationPortrait = 0
    acPlotOrientationLandscape = 1


class AcEntityName(IntFlag):
    ac3dFace = 1
    ac3dPolyline = 2
    ac3dSolid = 3
    acArc = 4
    acAttribute = 5
    acAttributeReference = 6
    acBlockReference = 7
    acCircle = 8
    acDimAligned = 9
    acDimAngular = 10
    acDimDiametric = 12
    acDimOrdinate = 13
    acDimRadial = 14
    acDimRotated = 15
    acEllipse = 16
    acHatch = 17
    acLeader = 18
    acLine = 19
    acMtext = 21
    acPoint = 22
    acPolyline = 23
    acPolylineLight = 24
    acPolymesh = 25
    acRaster = 26
    acRay = 27
    acRegion = 28
    acShape = 29
    acSolid = 30
    acSpline = 31
    acText = 32
    acTolerance = 33
    acTrace = 34
    acPViewport = 35
    acXline = 36
    acGroup = 37
    acMInsertBlock = 38
    acPolyfaceMesh = 39
    acMLine = 40
    acDim3PointAngular = 41
    acExternalReference = 42
    acTable = 43
    acDimArcLength = 44
    acDimRadialLarge = 45
    acDwfUnderlay = 46
    acDgnUnderlay = 47
    acMLeader = 48
    acSubDMesh = 49
    acPdfUnderlay = 50
    acNurbSurface = 51


class AcViewportScale(IntFlag):
    acVpScaleToFit = 0
    acVpCustomScale = 1
    acVp1_1 = 2
    acVp1_2 = 3
    acVp1_4 = 4
    acVp1_5 = 5
    acVp1_8 = 6
    acVp1_10 = 7
    acVp1_16 = 8
    acVp1_20 = 9
    acVp1_30 = 10
    acVp1_40 = 11
    acVp1_50 = 12
    acVp1_100 = 13
    acVp2_1 = 14
    acVp4_1 = 15
    acVp8_1 = 16
    acVp10_1 = 17
    acVp100_1 = 18
    acVp1_128in_1ft = 19
    acVp1_64in_1ft = 20
    acVp1_32in_1ft = 21
    acVp1_16in_1ft = 22
    acVp3_32in_1ft = 23
    acVp1_8in_1ft = 24
    acVp3_16in_1ft = 25
    acVp1_4in_1ft = 26
    acVp3_8in_1ft = 27
    acVp1_2in_1ft = 28
    acVp3_4in_1ft = 29
    acVp1in_1ft = 30
    acVp1and1_2in_1ft = 31
    acVp3in_1ft = 32
    acVp6in_1ft = 33
    acVp1ft_1ft = 34


class AcZoomScaleType(IntFlag):
    acZoomScaledAbsolute = 0
    acZoomScaledRelative = 1
    acZoomScaledRelativePSpace = 2


class AcCoordinateSystem(IntFlag):
    acWorld = 0
    acUCS = 1
    acDisplayDCS = 2
    acPaperSpaceDCS = 3
    acOCS = 4


class AcOleQuality(IntFlag):
    acOQLineArt = 0
    acOQText = 1
    acOQGraphics = 2
    acOQPhoto = 3
    acOQHighPhoto = 4


class AcUnits(IntFlag):
    acDefaultUnits = -1
    acScientific = 1
    acDecimal = 2
    acEngineering = 3
    acArchitectural = 4
    acFractional = 5


class AcPrinterSpoolAlert(IntFlag):
    acPrinterAlwaysAlert = 0
    acPrinterAlertOnce = 1
    acPrinterNeverAlertLogOnce = 2
    acPrinterNeverAlert = 3


class AcadSecurityParamsType(IntFlag):
    ACADSECURITYPARAMS_ENCRYPT_DATA = 1
    ACADSECURITYPARAMS_ENCRYPT_PROPS = 2
    ACADSECURITYPARAMS_SIGN_DATA = 16
    ACADSECURITYPARAMS_ADD_TIMESTAMP = 32


class AcadSecurityParamsConstants(IntFlag):
    ACADSECURITYPARAMS_ALGID_RC4 = 26625


class AcMeasurementUnits(IntFlag):
    acEnglish = 0
    acMetric = 1


class AcPlotPaperUnits(IntFlag):
    acInches = 0
    acMillimeters = 1
    acPixels = 2


class AcDragDisplayMode(IntFlag):
    acDragDoNotDisplay = 0
    acDragDisplayOnRequest = 1
    acDragDisplayAutomatically = 2


class AcPlotPolicyForNewDwgs(IntFlag):
    acPolicyNewDefault = 0
    acPolicyNewLegacy = 1


class AcPlotPolicyForLegacyDwgs(IntFlag):
    acPolicyLegacyDefault = 0
    acPolicyLegacyQuery = 1
    acPolicyLegacyLegacy = 2


class AcTextGenerationFlag(IntFlag):
    acTextFlagBackward = 2
    acTextFlagUpsideDown = 4


class AcToolbarDockStatus(IntFlag):
    acToolbarDockTop = 0
    acToolbarDockBottom = 1
    acToolbarDockLeft = 2
    acToolbarDockRight = 3
    acToolbarFloating = 4


ACAD_LWEIGHT = AcLineWeight
ACAD_COLOR = AcColor


__all__ = [
    'acDegrees180', 'acTitleSuppressed', 'AcadSubEntity',
    'acAttachmentMiddle', 'acDimPrecisionSeven',
    'acCellStateFormatLocked', 'acAngular',
    'AcPlotPolicyForLegacyDwgs', 'acLsNewViewport', 'acArrowArchTick',
    'acTitleRowTextStyle', 'AcadEllipse', 'acContentLayout',
    'acBottomMask', 'acInsertUnitsUnitless',
    'acHeaderHorzBottomLineWeight', 'AcMLeaderContentType',
    'ac270degrees', 'AcOnOff', 'acPixels',
    'acDemandLoadOnObjectDetect', 'acHeaderVertInsideVisibility',
    'AcDataLinkUpdateDirection', 'AcadPolygonMesh', 'AcDimUnits',
    'ACADSECURITYPARAMS_SIGN_DATA', 'acHeaderHorzTopColor',
    'acHeight', 'acEnglish', 'acLnWt035', 'IAcadSectionTypeSettings',
    'IAcadSubEntSolidEdge', 'AcMeasurementUnits', 'acExtendNone',
    'IAcadDimRotated', 'AcadDimArcLength', 'acDegrees60', 'AcadSolid',
    'acCreaseByLevel', 'IAcad3DFace', 'IAcadHyperlinks',
    'AcBlockScaling', 'acLnWt090', 'acScaleToFit',
    'AcKeyboardPriority', 'AcadRevolvedSurface',
    'AcadSecurityParamsType', 'AcGridLineType', 'IAcadGroups',
    'acHeaderVertRightColor', 'acDataTypeAndFormat', 'AcadDimension',
    'acVp1ft_1ft', 'AcDragDisplayMode', 'acSqrtChord', 'acOff',
    'acArrowDatumBlank', 'AcToolbarItemType',
    'acInsertUnitsLightYears', 'IAcadUCS', 'acVertInside',
    'acViewport4', 'acSectionSubItemkNone', 'acLnWt000',
    'acInsertUnitsAstronomicalUnits', 'IAcadPreferencesProfiles',
    'acLnWt053', 'acLnWt140', 'acCenterAlignment', 'acIntensity',
    'acArc', 'AcPlotPaperUnits', 'IAcadDictionaries', 'acR15_dwg',
    'ac2000_dwg', 'acDate', 'acUnitless', 'acVp8_1',
    'acInsertUnitsMils', 'acVp1_100', 'acRadians', 'acSmooth',
    'acHatchLoopTypeDefault', 'acDataRowFillNone',
    'IAcadAttributeReference', 'acCellRightGridColor',
    'acArrowBoxBlank', 'acIntensityEditableFlag', 'acCellMarginLeft',
    'acLong', 'acEllipse', 'acRuled', 'AcHatchObjectType',
    'acLnWt080', 'AcUnits', 'acDimFractionalStacked',
    'acArrowOrigin2', 'acPenWidth140', 'acInsertUnitsHectometers',
    'acCellAlign', 'IAcadLayouts', 'acProxyBoundingBox',
    'acHorizontalAlignmentAligned', 'AcadTolerance', 'acRightToLeft',
    'acCellBackgroundColor', 'acDataHorzBottomColor', 'IAcadUtility',
    'acMarginBottom', 'AcPolymeshType', 'acTitleVertLeftVisibility',
    'acCellBottomGridColor', 'acVerticalAlignmentBaseline',
    'acTitleRow', 'AcadIdPair', 'IAcadObjectEvents', 'acVp3_8in_1ft',
    'AcadPreferencesSelection', 'acWindow', 'acDragDoNotDisplay',
    'AcadEntity', 'AcCellType', 'acPolicyNamed',
    'AcToolbarDockStatus', 'AcadDatabasePreferences',
    'acDimRadialLarge', 'IAcadMenuGroups', 'acSectionType3dSection',
    'AcadDimOrdinate', 'ac1_10', 'acSectionSubItemVerticalLineBottom',
    'acShadePlotRendered', 'AcadPlotConfiguration',
    'acSectionSubItemBackLine', 'IAcad3DSolid', 'acNative',
    'AcAlignment', 'acAttributeModeConstant', 'acExternalReference',
    'IAcadLeader', 'AcDimCenterType', 'acTextFlagBackward',
    'ac3_4in_1ft', 'acDragDisplayAutomatically', 'acConnectExtents',
    'acVp1_64in_1ft', 'acArrowOpen30', 'acInsertUnitsFeet',
    'AcEntityName', 'acTolNone', 'acAlignmentTopLeft',
    'acMenuFileCompiled', 'acVerticalAlignmentMiddle',
    'IAcadDatabasePreferences', 'AcadPdfUnderlay',
    'acTitleRowTextHeight', 'AcadPreferencesSystem', 'acProxyNotShow',
    'acSectionSubItemBackLineBottom', 'acCastsAndReceivesShadows',
    'acHeaderSuppressed', 'ACAD_ANGLE', 'acSectionType2dSection',
    'acLayout', 'AcSectionState2', 'acVp1_8in_1ft',
    'acDimPrecisionZero', 'acAttachmentBottomOfTop',
    'acAttachmentBottomLine', 'acViewport3Left',
    'AcadSectionSettings', 'acSectionSubItemSectionLineTop',
    'acSubDMesh', 'ac1_4in_1ft', 'IAcadDimStyles',
    'acHorizontalAlignmentMiddle', 'AcAlignmentPointAcquisition',
    'acLnWt040', 'acForExpression', 'acIntensities',
    'AcadPreferencesOutput', 'ac2004_dwg', 'acTrueColor',
    'AcValueUnitType', 'AcLayerStateMask', 'AcadAcCmColor',
    'acRaster', 'AcadPreferences', 'acForEditing', 'AcadDwfUnderlay',
    'ac1_16', 'Acad3DSolid', 'acAlignmentProperty', 'acBottomRight',
    'acHeaderHorzInsideLineWeight', 'acPreDefinedGradient',
    'IAcadMLeader', 'acTitleRowAlignment', 'IAcadGeoPositionMarker',
    'acEnableSCM', 'acStraightLeader', 'acUniform', 'acLnWt100',
    'AcadSelectionSets', 'acFlowDirBtoT', 'IAcadDimension',
    'AcadExternalReference', 'acShape', 'acFractional',
    'AcadPreferencesFiles', 'acSectionGenerationDestinationFile',
    'AcadDgnUnderlay', 'ac1_1', 'acVertCellMargin',
    'IAcadMLeaderStyle', 'IAcadTextStyles', 'acIsoparms',
    'IAcadWipeout', 'AcRowType', 'acTitleVertRightVisibility',
    'acMLine', 'acDemandLoadDisabled', 'acMenuFileSource',
    'acTitleHorzInsideVisibility', 'acConnectBase', 'AcDimFit',
    'acObjectId', 'acBlockCell', 'acDegreeMinuteSeconds',
    'acDimArcLength', 'acPolicyLegacyLegacy', 'acLnWt070',
    'AcCoordinateSystem', 'ac1_50', 'AcInsertUnitsAction',
    'acAttributeModeMultipleLine', 'acOTLink', 'AcadDatabase',
    'AcadPointCloudEx', 'AcadRegisteredApplications', 'acLsColor',
    'acCellMarginHorzSpacing', 'acLineNoArrow', 'AcExtendOption',
    'typelib_path', 'IAcadLoftedSurface', 'ac1_2in_1ft',
    'acKeyboardEntryExceptScripts', 'IAcadXline',
    'acSectionSubItemBackLineTop', 'acMenuSeparator', 'acArea',
    'AcadObject', 'AcadXRecord', 'acQuadSurfaceMesh', 'IAcadPoint',
    'acNormal', 'acPViewport', 'acTitleVertLeftLineWeight',
    'acAttribute', 'acSymNone', 'acAttachmentTopOfTop',
    'AcSaveAsType', 'acInsertUnitsYards', 'AcadSubDMeshVertex',
    'acCW', 'acModelSpace', 'IAcadText', 'acArrowDotSmall', 'ac2_1',
    'acDataHorzTopVisibility', 'acTextOnly', 'acTextCell',
    'acLnWt200', 'IAcadHelix', 'acSectionState2Volume', 'AcadTrace',
    'acEnter', 'acSectionTypeLiveSection', 'acHeaderVertLeftColor',
    'acAttachmentCenter', 'IAcadSection',
    'acSectionGenerationSourceAllObjects', 'acIntensityGrayscale',
    'acGeneral', 'AcPatternType', 'IAcadLine', 'acDataRowColor',
    'acPolyline', 'acTable', 'acCustomParameterization',
    'acDimLFractional', 'acCellStateNone', 'AcDrawingAreaSCMCommand',
    'IAcadDwfUnderlay', 'IAcadSummaryInfo', 'acSetDefaultFormat',
    'acActiveViewport', 'IAcadObject', 'acVp1_8', 'AcadDimStyles',
    'acCellTopVisibility', 'IAcadDimDiametric', 'acView',
    'IAcadPointCloudEx', 'AcadModelSpace', 'acVp1_5', 'acEngineering',
    'acHeaderVertInsideColor', 'acGradientObject', 'IAcadEllipse',
    'acAttributeReference', 'AcMenuGroupType',
    'AcPointCloudStylizationType', 'acUnitAngle', 'AcDimLUnits',
    'acAlignmentFit', 'IAcadPreferencesSelection', 'ac8_1',
    'acNotStacked', 'AcadOle', 'acInsertUnitsNanometers',
    'acAttachmentPointTopRight', 'acLsLineWeight', 'acCircle',
    'AcadApplication', 'acTitleHorzTopColor', 'acZoomScaledAbsolute',
    'acTrace', 'AcadDimRadialLarge', 'AcadState',
    'AcDimToleranceMethod', 'acRightAlignment', 'acIntersection',
    'acRegion', 'IAcadMenuGroup', 'acCellContentTypeField',
    'IAcadSectionTypeSettings2', 'acCellMarginRight',
    'acMTextContent', 'acHatchObject', 'acPolicyLegacy',
    'AcadViewport', 'AcDimVerticalJustification',
    'acSectionState2Boundary', 'acR18_dxf', 'AcGridLineStyle',
    'acSectionState2Slice', 'AcLeaderType', 'acBlockUserDefined',
    'IAcadShape', 'IAcadPaperSpace', 'acDemandLoadEnabledWithCopy',
    'IAcadPreferencesOpenSave', 'acSplineNoArrow', 'IAcadNurbSurface',
    'acTitleVertInsideLineWeight', 'acHeaderVertInsideLineWeight',
    'acKeyboardRunningObjSnap', 'acScanColor',
    'acAttachmentBottomOfBottom', 'acMarginTop', 'ac1_8',
    'AcadLineType', 'IAcadSecurityParams', 'acVp1_4in_1ft',
    'acDataRow', 'AcadLayout', 'acPaletteByDrawing',
    'AcadDim3PointAngular', 'AcadPolyline', 'acUpdateSourceFromData',
    'IAcadShadowDisplay', 'acIntensityRed', 'AcadUtility',
    'acHeaderRowFillColor', 'acCellBackgroundFillNone',
    'acCastsShadows', 'acPaperSpace', 'acTextHeight',
    'IAcadPreferences', 'acByColor', 'acPenWidth025', 'AcISOPenWidth',
    'acShadePlotWireframe', 'acHeaderRowColor', 'acLnWtByLwDefault',
    'acVp1_1', 'AcCellOption', 'acLnWt013', 'ACAD_LTYPE',
    'acDimLScientific', 'AcadViewports', 'acInvalidCellProperty',
    'acShadePlotHidden', 'AcadPopupMenuItem', 'acVp1_2in_1ft',
    'ac100_1', 'acR13_dwg', 'acMergeCellStyleCopyDuplicates',
    'acPlotOrientationLandscape', 'acDegrees30', 'acFontBold',
    'AcadUCS', 'acCellRightGridLineWeight', 'acVp3_4in_1ft',
    'acAlwaysCrease', 'AcadSectionTypeSettings', 'IAcadMLeaderLeader',
    'acDemanLoadDisable', 'acFlowDirection', 'IAcadApplication',
    'acLnWt015', 'acLineSpacingStyleExactly', 'AcadGeomapImage',
    'ac3dPolyline', 'acMarginLeft', 'acFullPreview',
    'acContentProperties', 'acInsertUnitsParsecs', 'acDegreesUnknown',
    'AcadSpline', 'AcadBlock', 'acArrowDot', 'AcViewportScale',
    'acR18_Template', 'acMiddleRight', 'acAlwaysRightReadingAngle',
    'AcDimFractionType', 'acInsertUnitsMiles', 'acOTEmbedded',
    'acVp6in_1ft', 'acCellStateFormatReadOnly', 'acAttachmentAllLine',
    'IAcadHyperlink', 'AcadSweptSurface', 'acHeaderRowAlignment',
    'acAttachmentBottomOfTopLine', 'acCubicSpline3DPoly',
    'acSelectionSetPrevious', 'acBottomLeft', 'AcadToolbar',
    'AcDynamicBlockReferencePropertyUnitsType', 'acHorzTop',
    'acTitleVertRightColor', 'acCellTextHeight',
    'AcTextAttachmentDirection', 'acVp1_40', 'acObjectColor', 'acCCW',
    'acMagenta', 'acDataRowTextStyle', 'ac1_128in_1ft',
    'acAlignmentAligned', 'acDataRowDataType', 'acArrowDotBlank',
    'acDemandLoadCmdInvoke', 'acSectionSubItemSectionLine',
    'acDataRowTextHeight', 'acUseDraftAngles', 'AcadLoftedSurface',
    'acR14_dwg', 'acTextStyle', 'AcadLineTypes',
    'acTitleHorzInsideColor', 'acTurnHeight', 'acFit',
    'acAttachmentVertical', 'acPolicyNewLegacy', 'AcadLWPolyline',
    'acVp1in_1ft', 'AcadAttribute', 'acAlignmentMiddleLeft',
    'acInsertUnitsMicrons', 'Acad3DPolyline', 'AcadBlocks',
    'AcShadowDisplayType', 'AcadTable', 'acTableSelectCrossing',
    'ac2000_dxf', 'acMin', 'AcadSubEntSolidEdge', 'AcadDimStyle',
    'AcActiveSpace', 'acArrowOpen', 'acDimAngular', 'acNoOverrides',
    'acTextAndArrows', 'AcHelixConstrainType', 'acTitleRowDataType',
    'acRed', 'acZoomScaledRelative', 'AcadSubDMesh',
    'AcPlotPolicyForNewDwgs', 'AcLoopType', 'acDimPrecisionOne',
    'acVerticalAlignmentBottom', 'acDimArchitectural',
    'acPartialMenuGroup', 'AcadTableStyle', 'IAcadDimRadial',
    'IAcadPreferencesUser', 'AcDrawingDirection', 'Acad3DFace',
    'AcPointCloudIntensityStyle', 'acToolbarFloating',
    'acDrawContentFirst', 'acOQLineArt', 'acOverFirstExtension',
    'ACAD_NOUNITS', 'acInsertUnitsUSSurveyFeet',
    'acSelectionSetFence', 'acAttributeModePreset',
    'acReceivesShadows', 'acAttachmentHorizontal',
    'acHorizontalAlignmentCenter', 'acPenWidth050', 'acFirstNormal',
    'acUpdateDataFromSource', 'IAcadSubEntSolidVertex', 'ac2004_dxf',
    'IAcadGroup', 'acDataHorzTopColor', 'ac4_1',
    'acCellContentLayoutStackedVertical', 'acWorld',
    'acCellContentLayoutFlow', 'IAcadBlockReference',
    'IAcadTolerance', 'acArrowOrigin', 'acCenterNone',
    'acViewport3Horizontal', 'acPartialPreview', 'ac0degrees',
    'IAcadLineTypes', 'AcParseOption', 'acDrawLeaderFirst',
    'acBackgroundColor', 'IAcadDictionary', 'IAcadSpline',
    'ac3in_1ft', 'acTitleVertInsideVisibility',
    'acHeaderHorzInsideColor', 'acTolDeviation',
    'acAttachmentPointMiddleLeft', 'IAcadLayer', 'acHeaderRow',
    'kFormatOptionNone', 'AcSectionSubItem', 'ac3_32in_1ft',
    'acMenuItem', 'ac2010_dwg', 'acCellBottomGridLineWeight',
    'acShow', 'acQuadSpline3DPoly', 'acFontBoldItalic',
    'ACADSECURITYPARAMS_ENCRYPT_PROPS', 'AcCellProperty',
    'acHorzCentered', 'acOQPhoto', 'IAcadLineType',
    'acTolSymmetrical', 'acHeaderRowTextStyle',
    'IAcadLayerStateManager', 'acHorizontalAngle',
    'acExtendOtherEntity', 'acLsFrozen', 'IAcadView', 'acArrowNone',
    'AcadMenuBar', 'acSectionGenerationDestinationNewBlock',
    'AcadDocument', 'acRepeatLastCommand', 'acOPQLowGraphics',
    'acLnWt020', 'AcSectionType', 'acViewport3Right',
    'acColorMethodByBlock', 'acBottomToTop', 'acLnWt158',
    'AcadMaterial', 'acToolbarFlyout', 'acDataVertRightVisibility',
    'acDimFractional', 'IAcadRasterImage', 'ac1_32in_1ft',
    'acSectionStateBoundary', 'AcadXline', 'acCenterMark',
    'acQuadSplinePoly', 'acCubicSplinePoly', 'AcColor', 'ac3dSolid',
    'acDataHorzInsideLineWeight', 'acRightMask', 'acDimRotated',
    'IAcadPointCloud', 'IAcad3DPolyline', 'ac1_40',
    'AcVerticalAlignment', 'AcOleQuality', 'AcWireframeType',
    'acInches', 'acSelectionSetCrossing', 'acAlignmentRight',
    'acTopLeft', 'IAcadPreferencesSystem', 'acMoveTextNoLeader',
    'acHatchLoopTypeTextbox', 'acZoomScaledRelativePSpace',
    'acLnWt005', 'acViewport2Vertical', 'ac1_16in_1ft',
    'IAcadSubDMeshEdge', 'acOPQHighGraphics', 'acPolicyLegacyDefault',
    'acHeaderVertLeftVisibility', 'acDataVertInsideLineWeight',
    'acBlockImperial', 'ACAD_POINT', 'AcadPolyfaceMesh',
    'acDimLEngineering', 'acVertRight', 'acInsertUnitsMillimeters',
    'acVertCentered', 'ac2007_dwg', 'IAcadPopupMenuItem',
    'acCellContentTypeBlock', 'acHeaderRowTextHeight',
    'acArrowDatumFilled', 'acTitleHorzTopLineWeight', 'acSpline',
    'acLnWt120', 'acDataRowAlignment', 'ac2010_dxf', 'acPenWidth013',
    'acCellContentTypeValue', 'acViewport3Below', 'acLsOn',
    'acAutoScale', 'IAcadRegisteredApplications', 'acPoint3d',
    'AcRotationAngle', 'acFontItalic', 'AcFormatOption',
    'IAcadDatabase', 'acToolbarDockLeft', 'acMillimeters',
    'AcadDictionary', 'AcadMLine', 'acLsNone', 'acVp3_16in_1ft',
    'AcadToolbarItem', 'acPolyfaceMesh', 'acNormals', 'acDecimal',
    'acLineSpacingStyleAtLeast', 'AcDimPrecision',
    'acFirstExtensionLine', 'acVp1and1_2in_1ft', 'ac1_30',
    'acBlockTriangle', 'AcDimTextMovement', 'IAcadToolbar', 'acTrue',
    'acCellStateFormatModified', 'acDisplay', 'acUserDefinedGradient',
    'IAcadSubDMesh', 'IAcadIdPair', 'AcGradientPatternType',
    'acInsertUnitsKilometers', 'acDegrees000', 'IAcadLayout',
    'AcadSummaryInfo', 'IAcadPreferencesDisplay', 'acLsLocked',
    'AcZoomScaleType', 'acAttachmentLinedCenter',
    'acInsertUnitsDecameters', 'AcTableFlowDirection',
    'AcadSecurityParams',
    'acUpdateOptionOverwriteContentModifiedAfterUpdate',
    'acTitleHorzInsideLineWeight', 'acDimPrecisionFour',
    'acR15_Template', 'AcTableStyleOverrides',
    'IAcadPreferencesFiles', 'AcadMenuGroups',
    'acHatchPatternTypePreDefined', 'IAcadPlaneSurface',
    'acCellMarginBottom', 'acVp100_1', 'IAcadOle', 'acSimplePoly',
    'AcMergeCellStyleOption', 'IAcadUnderlay', 'IAcadTextStyle',
    'AcSplineFrameType', 'IAcadDocument', 'AcPredefBlockType',
    'acInsertUnitsDecimeters', 'AcSegmentAngleType', 'ac1_8in_1ft',
    'IAcadDimRadialLarge', 'AcadTextStyles', 'acViewport3Above',
    'acTitleVertRightLineWeight', 'acDimPrecisionFive', 'AcadLayer',
    'AcWindowState', 'acOTStatic', 'acSymInFront', 'acUnitVolume',
    'acEdRepeatLastCommand', 'acArrowsOnly', 'AcadSubEntSolidNode',
    'acDgnUnderlay', 'LONG_PTR', 'acUnknownDataType', 'ac2007_dxf',
    'acVp1_128in_1ft', '_DAcadDocumentEvents',
    'acHatchLoopTypePolyline', 'AcPolylineType', 'AcadTextStyle',
    'acEnableBackgroundColor', 'acUnitDistance', 'acVp3_32in_1ft',
    'ac1_4', 'AcadMLeaderStyle', 'acResbuf', 'IAcadViewports',
    'acBlockSlot', 'AcCellAlignment', 'acArrowSmall', 'ac1_20',
    'acTurns', 'AcKeyboardAccelerator', 'acAlignmentTopRight',
    'acCellStateLinked', 'acBuffer', 'IAcadMInsertBlock',
    'acAlignPntAcquisitionShiftToAcquire', 'IAcadPointCloudEx2',
    'AcadLine', 'acTolerance', 'acDimLWindowsDesktop', 'acPoint2d',
    'AcadGroups', 'AcBooleanType', 'AcCellEdgeMask',
    'acHeaderHorzTopVisibility', 'AcadSubEntSolidVertex',
    'acSplineLeader', 'acMtext', 'acAttachmentMiddleOfBottom',
    'AcSectionState', 'acDataVertInsideVisibility',
    'AcAttachmentPoint', 'acCellTopGridLineWeight', 'acDwfUnderlay',
    'acCellContentColor', 'AcLineSpacingStyle', 'acExtents',
    'acToolbarDockBottom', 'acPoint', 'acUnknown', 'acAllNormal',
    'acMarginRight', 'IAcadMenuBar', 'acArrowOpen90',
    'acAlignmentBottomLeft', 'acGreen', 'IAcadRegisteredApplication',
    'acAllCellProperties', 'AcadMLeader', 'IAcadDimArcLength',
    'acEnableSCMOptions', 'AcadPreferencesUser',
    'acDataVertRightLineWeight', 'acDouble', 'AcadToolbars',
    'AcadAttributeReference', 'AcOlePlotQuality',
    'acTitleRowFillNone', 'AcTextFontStyle',
    'acDataHorzTopLineWeight', 'acLimits',
    'AcadRegisteredApplication', 'acInsertUnitsGigameters',
    'acLnWt030', 'AcadSubEntSolidFace', 'acHorizontalAlignmentRight',
    'AcadRegion', 'AcDrawMLeaderOrderType', 'acPaletteBySession',
    'IAcadRevolvedSurface', 'acDimOrdinate', 'acAlignmentMiddleRight',
    'acAlignmentBottomRight', 'acUnknownRow', 'acAttributeModeVerify',
    'ac2010_Template', 'AcadFileDependencies', 'acR13_dxf',
    'AcadPopupMenus', 'acInvalidGridLine', 'AcMenuItemType',
    'acPrinterNeverAlertLogOnce', 'AcCellContentType',
    'acToolbarDockTop', 'IAcadBlocks',
    'acHatchPatternTypeUserDefined', 'AcXRefDemandLoad',
    'AcadSelectionSet', 'acColorMethodByACI', 'ac1_64in_1ft',
    'ACAD_COLOR', 'AcadText', 'acUpdateOptionUpdateFullSourceRange',
    'acShadePlotAsDisplayed', 'AcDimArcLengthSymbol',
    'IAcadGeomapImage', 'AcadPreferencesOpenSave',
    'acHorizontalAlignmentFit', 'AcadDimRadial', 'acDimEngineering',
    'AcadHelix', 'acColorMethodForeground', 'acCellLeftVisibility',
    'acPreferenceClassic',
    'acMergeCellStyleConvertDuplicatesToOverrides', 'acLsLineType',
    'acToolbarControl', 'acProxyShow', 'AcadGroup', 'AcBoolean',
    'acInsertUnitsMicroinches', 'acAttachmentPointBottomCenter',
    'AcDrawingAreaSCMDefault', 'acPenWidthUnk', 'acDimPrecisionTwo',
    'acDimArchitecturalStacked', 'acDegrees90', 'acDegrees090',
    'AcTextAngleType', 'acBestFit', 'acInsertUnitsPrompt',
    'acTitleRowColor', 'acTop', 'AcadPlotConfigurations',
    'acDimLineWithText', 'AcadLeader', 'AcMenuFileType',
    'acClassification', 'acHorzBottom', 'acScientific',
    'acArrowClosed', 'ACAD_DISTANCE', 'acSymAbove', 'acCenterLine',
    'AcShadePlot', 'acCyan', 'AcadMInsertBlock', 'AcadPlot',
    'acVp1_2', 'IAcadDimOrdinate', 'acDimPrecisionEight',
    'acMergeCellStyleOverwriteDuplicates',
    'acHeaderHorzInsideVisibility', 'IAcadPolyline', 'AcadMText',
    'acR15_dxf', 'acLnWt009', 'AcPreviewMode', 'acSubtraction',
    'acHeaderVertLeftLineWeight', 'acPenWidth200',
    'acAlignmentMiddle', 'AcTableDirection', 'AcDataLinkUpdateOption',
    'acSectionStatePlane', 'IAcadPopupMenus', 'AcadLayouts',
    'AcadMLeaderLeader', 'acDimRadial', 'acHeaderVertRightLineWeight',
    'AcVerticalTextAttachmentType', 'acTitleRowFillColor',
    'acHeaderRowFillNone', 'acAlignmentTopCenter', 'acBottom',
    'acDimWindowsDesktop', 'acLeftAlignment', 'ac2004_Template',
    'acAttachmentPointTopLeft', 'ac3dFace', 'acBlockContent',
    'acInsertUnitsAutoAssign', 'acInsertUnitsCentimeters',
    'IAcadSection2', 'acHide', 'acMLeader',
    'acCellStateContentLocked', 'acByLayer', 'ac2000_Template',
    'AcAttributeMode', 'AcadDocuments',
    'acUseDefaultDrawingAreaShortCutMenu', 'acAlignmentLeft',
    'AcValueDataType', 'acCellStateContentReadOnly',
    'acHorizontalAlignmentLeft', 'IAcadDimAngular',
    'IAcadSweptSurface', 'acCellRightVisibility', 'acGroup',
    'AcDimHorizontalJustification', 'AcOleType', 'acBlockHexagon',
    'acTableBottomToTop', 'acUnknownCell', 'AcadArc', 'acDataType',
    'IAcadPreferencesDrafting', 'acSelectionSetAll', 'acXline',
    'AcadLayerStateManager', 'acTableFlowDownOrUp',
    'acDataHorzInsideVisibility', 'AcHorizontalAlignment',
    'acMergeAll', 'acDemandLoadEnabled',
    'acNoDrawingAreaShortCutMenu', 'AcadSortentsTable',
    'acDataVertInsideColor', 'AcadNurbSurface',
    'acAttachmentPointTopCenter', 'AcInsertUnits', 'acContentColor',
    'acVp1_10', 'acDimDiametric', 'acDataHorzInsideColor',
    'AcadCircle', 'AcadDimRotated', 'acIntensityRainbow', 'AcadUCSs',
    'acDegrees270', 'IAcadRay', 'acArrowIntegral',
    'IAcadSubEntSolidNode', 'acNurbSurface', 'AcadHatch', 'acHatch',
    'IAcadArc', 'acUpdateOptionOverwriteFormatModifiedAfterUpdate',
    'acR12_dxf', 'acPolicyLegacyQuery', 'acDataHorzBottomLineWeight',
    'acLnWt106', 'IAcadSolid', 'IAcadSelectionSet', 'acFalse',
    'acAttributeModeNormal', 'ACADSECURITYPARAMS_ADD_TIMESTAMP',
    'acByStyle', 'acAlignmentBottomCenter', 'ac3_16in_1ft',
    'acOQGraphics', 'AcDrawingAreaShortCutMenu', 'acMenuSubMenu',
    'acSolid', 'acSectionSubItemVerticalLineTop',
    'acHatchPatternTypeCustomDefined', 'acSelectionSetWindow',
    'acPenWidth100', 'acApplied', 'IAcadFileDependency',
    'AcadBlockReference', 'acDimPrecisionSix',
    'acDragDisplayOnRequest', 'acInVisibleLeader', 'acTopToBottom',
    'acPlotOrientationPortrait', 'AcARXDemandLoad', 'ac180degrees',
    'AcColorMethod', 'AcMLineJustification', 'acEdSCM',
    'acSectionGenerationDestinationReplaceBlock',
    'AcadGeoPositionMarker', 'acLnWt018',
    'acAttributeModeLockPosition', 'acIntensityBlue',
    'IAcadPlotConfiguration', 'AcPointCloudColorType',
    'acIgnoreShadows', 'ac1_2', 'IAcadMLine', 'AcLineWeight',
    'acTopCenter', 'AcSelect', 'acOQText', 'acPenWidth035',
    'acIntensityGreen', 'ac1ft_1ft', 'acLnWtByLayer',
    'acTableTopToBottom', 'IAcadExtrudedSurface', 'AcadPointCloud',
    'AcProxyImage', 'IAcadSectionSettings', 'acMergeCellStyleNone',
    'AcadDimAligned', 'acLeader', 'IAcadToolbars',
    'acInsertUnitsMeters', 'acVp1_30', 'acArrowDefault',
    'IAcadPopupMenu', 'IAcadPolyfaceMesh',
    'acCellStateContentModified', 'acAlignPntAcquisitionAutomatic',
    'acEndsNormal', 'acDegrees15', 'acViewport2Horizontal',
    'acCellTopGridColor', 'acDim3PointAngular', 'Library',
    'acMoveTextAddLeader', 'acNoneCrease', 'IAcadTrace', 'acVertLeft',
    'acCubicSurfaceMesh', 'acFontRegular', 'AcPlotScale',
    'acMiddleCenter', 'acHorizontal',
    'acSectionGenerationSourceSelectedObjects', 'AcPlotRotation',
    'acBottomCenter', 'acVp2_1', 'AcDimArrowheadType', 'acScale',
    'acSCM', 'acVp1_16in_1ft', 'acOCS', 'IAcadPlot', 'AcLoadPalette',
    'AcadPoint', 'AcadRasterImage', 'acInsertUnitsAngstroms',
    'acBezierSurfaceMesh', 'IAcadFileDependencies', 'AcMLeaderType',
    'acUnion', 'acPrinterAlwaysAlert', 'acCellTextStyle',
    'acHatchLoopTypeDerived', 'acUnder', 'acViewport3Vertical',
    'acSecondExtensionLine', 'acVp10_1', 'acPolylineLight',
    'AcPointCloudExStylizationType', 'acAttachmentPointMiddleCenter',
    'acUniformParam', 'acUnitArea', 'acInsertUnitsUSSurveyYard',
    'IAcadSubEntity', 'IAcadSortentsTable', 'acPreserveMtextFormat',
    'AcLoftedSurfaceNormalType', 'ac2013_Template',
    'AcMeshCreaseType', 'acKeyboardEntry', 'ac2007_Template',
    'acHorzInside', 'acLock', 'acArrowUserDefined',
    'acColorMethodByLayer', 'acDimLDecimal', 'acGridLineStyleDouble',
    'acPrinterNeverAlert', 'AcadPreferencesProfiles', 'acBlue',
    'AcDrawLeaderOrderType', 'acDiagonal', 'acAttributeModeInvisible',
    'acLsPlotStyle', 'acCellMarginTop', 'acVp1_32in_1ft',
    'AcDrawingAreaSCMEdit', 'acIgnoreMtextFormat', 'acNoneContent',
    'acDimLArchitectural', 'IAcadSelectionSets', 'acToolbarButton',
    'IAcadModelSpace', 'acVpScaleToFit', 'IAcadSubEntSolidFace',
    'acHorzCellMargin', 'IAcadRegion',
    'acSectionSubItemSectionLineBottom', 'AcadDimAngular',
    'acSplineWithArrow', 'acDimPrecisionThree', 'IAcadAttribute',
    'acSimple3DPoly', 'kInheritCellFormat', 'IAcadDimStyle',
    'AcAngleUnits', 'ac3_8in_1ft', 'acUpdateOptionNone', 'ac10_1',
    'IAcadMText', 'AcadExtrudedSurface', 'AcadPreferencesDrafting',
    'IAcadState', 'IAcadToolbarItem', 'AcadPreferencesDisplay',
    'acHeaderVertRightVisibility', 'acSelectionSetLast', 'ac2013_dwg',
    'acLnWt050', 'acSimpleMesh', 'acTitleHorzBottomLineWeight',
    'acTolTop', 'IAcadMaterials', 'acDimAligned', 'acNorm',
    'acAttachmentPointBottomLeft', 'acDegreesHorz', 'AcadMaterials',
    'acHatchLoopTypeExternal', 'acBlockCircle', 'acNoUnits',
    'acCellContentLayoutStackedHorizontal',
    'AcSplineKnotParameterizationType', 'AcPrinterSpoolAlert',
    'acInsertUnitsInches', 'AcadDictionaries', 'acUCS',
    'AcTextGenerationFlag', 'AcadMenuGroup', 'AcadFileDependency',
    'ac1in_1ft', 'acRotation', 'AcTextAttachmentType',
    'AcTextAlignmentType', 'AcadSubDMeshFace',
    'AcDimToleranceJustify', 'acLeftMask',
    'AcUnderlayLayerOverrideType', 'acHatchStyleOuter',
    'acControlVertices', 'AcadRay', 'AcadSection', 'acVp1_4',
    'IAcadSubDMeshFace', 'acTopRight', 'acTolBottom', 'acLnWt025',
    'IAcadPlotConfigurations', 'acTitleHorzBottomColor',
    'acArrowBoxFilled', 'acByBlock', 'IAcadPViewport',
    'acDataVertRightColor', 'IAcadLWPolyline', 'acCellDataType',
    'acPenWidth018', 'acDataHorzBottomVisibility', 'acMiddleLeft',
    'acRay', 'acDistance', 'acDimDecimal', 'AcSectionGeneration',
    'AcadSurface', 'acTolBasic', 'acDrawLeaderTailFirst', 'ACAD_NULL',
    'acVp1_20', 'IAcadDynamicBlockReferenceProperty',
    'AcBlockConnectionType', 'AcadPlaneSurface', 'ac90degrees',
    'acCellLeftGridColor', 'acTextFlagUpsideDown', 'acDegreesAny',
    'acOverSecondExtension', 'ac1_100', 'acTolLimits',
    'acDataVertLeftColor', 'acTopMask', 'acHatchStyleNormal',
    'acInsertAngle', 'acGridLineStyleSingle', 'acOQHighPhoto',
    'acInsertUnitsUSSurveyInch', 'acArrowClosedBlank',
    'AcHelixTwistType', 'IAcadTableStyle',
    'ACADSECURITYPARAMS_ENCRYPT_DATA', 'acColorMethodByRGB',
    'acDisplayDCS', 'acBlockBox', 'acInsertUnitsUSSurveyMile',
    'acHeaderHorzTopLineWeight', 'acAttachmentPointBottomRight',
    'acCellLeftGridLineWeight', 'acTableFlowLeft',
    'acAttachmentPointMiddleRight', 'AcadWipeout', 'AcadLayers',
    'IAcadEntity', 'AcadHyperlinks', 'acVp1_50', 'acOutside',
    'AcadView', 'acObject', 'acArrowOblique', 'acToolbarDockRight',
    'AcPlotPolicy', 'acPdfUnderlay', 'AcadPaperSpace',
    'acTableFlowRight', 'acTitleHorzTopVisibility', 'acText',
    'IAcadMaterial', 'acR18_dwg', 'acZero', 'acPrinterAlertOnce',
    'AcCellContentLayout', 'acMergeCellStyleIgnoreNewStyles',
    'IAcadSectionManager', 'acElevation', 'AcadPopupMenu', 'acVp1_16',
    'ACADSECURITYPARAMS_ALGID_RC4', 'acString', 'acPenWidth070',
    'AcadDimDiametric', 'acAny', 'acAlignmentMiddleCenter',
    'AcadSectionManager', 'ac6in_1ft', 'IAcadLayers', 'IAcadBlock',
    'AcPlotType', 'acLnWt060', 'acHeaderHorzBottomVisibility',
    'acDegrees45', 'acLastNormal', 'acPaperSpaceDCS',
    'acSectionStateVolume', 'acVerticalAlignmentTop', 'ACAD_LWEIGHT',
    'IAcadTable', 'acLine', 'acDataVertLeftLineWeight',
    'IAcadExternalReference', 'acSelectionSetWindowPolygon',
    'acVpCustomScale', 'IAcadViewport', 'AcHatchStyle',
    'IAcadDocuments', 'acYellow', 'acTitleHorzBottomVisibility',
    'acFitCurvePoly', 'acExtendThisEntity', 'acMInsertBlock',
    'acSectionState2Plane', 'IAcadDim3PointAngular', 'AcadViews',
    'acGrads', 'acLsAll', 'AcadDynamicBlockReferenceProperty',
    'acParseOptionNone', 'IAcadSubDMeshVertex', 'acRGB',
    'IAcadDimAligned', 'acCellMarginVertSpacing',
    'acTitleVertInsideColor', 'Ac3DPolylineType', 'ACAD_LAYER',
    'AcadHyperlink', 'kCellOptionNone', 'acLnWtByBlock',
    'acDimScientific', 'acPolicyNewDefault', 'acTitleVertLeftColor',
    'acLsPlot', 'acArchitectural', 'acPolymesh', 'acR14_dxf',
    'ac2013_dxf', 'acLineWithArrow', 'AcCellMargin',
    'AcPlotOrientation', 'acWhite', 'acHatchStyleIgnore',
    'IAcadViews', 'IAcadAcCmColor', 'acTableSelectWindow',
    'acHeaderRowDataType', 'acUseMaximumPrecision',
    'acCellBottomVisibility', 'acTolMiddle', 'acDegrees',
    'AcSelectType', 'IAcadSurface', 'acCellContentTypeUnknown',
    '_DAcadApplicationEvents', 'IAcadPreferencesOutput',
    'AcSplineMethodType', 'acVp4_1', 'IAcadXRecord', 'AcadShape',
    'acDataVertLeftVisibility', 'IAcadHatch', 'acLnWt211',
    'acAlignmentCenter', 'acChord', 'acBitProperties',
    'acSelectionSetCrossingPolygon', 'acAllViewports',
    'acBlockReference', 'acOn', 'acDataRowFillColor',
    'AcadSecurityParamsConstants', 'acOPQMonochrome', 'AcCellState',
    'acDrawLeaderHeadFirst', 'acPreferenceCustom',
    'acToolbarSeparator', 'AcadSubDMeshEdge', 'acLeftToRight',
    'AcViewportSplitType', 'acAbove', 'AcRegenType', 'ac1_5',
    'acMetric', 'acExtendBoth', 'IAcadCircle',
    'acUpdateOptionIncludeXrefs', 'acIsolines', 'IAcadUCSs', 'acMax',
    'acBaseMenuGroup', 'acHeaderHorzBottomColor',
    'acAttachmentMiddleOfTop', 'acJIS', 'acVp3in_1ft',
    'IAcadPolygonMesh', 'acDefaultUnits', 'acDataFormat',
    'AcadPViewport'
]


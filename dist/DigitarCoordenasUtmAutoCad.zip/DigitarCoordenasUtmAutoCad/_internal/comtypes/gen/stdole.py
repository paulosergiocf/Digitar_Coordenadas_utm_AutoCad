from enum import IntFlag

import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 as __wrapper_module__
from comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 import (
    OLE_XSIZE_CONTAINER, IFont, OLE_HANDLE, FONTSTRIKETHROUGH,
    OLE_CANCELBOOL, OLE_YSIZE_HIMETRIC, StdPicture, CoClass,
    OLE_YPOS_PIXELS, VARIANT_BOOL, Font, OLE_XPOS_PIXELS, DISPPARAMS,
    Monochrome, FONTBOLD, _lcid, Gray, OLE_COLOR, Checked,
    OLE_YPOS_CONTAINER, IEnumVARIANT, IFontDisp, OLE_YSIZE_PIXELS,
    Default, OLE_XSIZE_PIXELS, COMMETHOD, Library, IFontEventsDisp,
    VgaColor, HRESULT, IUnknown, StdFont, _check_version,
    OLE_YSIZE_CONTAINER, EXCEPINFO, Unchecked, FONTUNDERSCORE,
    Picture, FONTSIZE, OLE_XSIZE_HIMETRIC, OLE_OPTEXCLUSIVE,
    OLE_YPOS_HIMETRIC, IPictureDisp, IPicture, FontEvents,
    typelib_path, FONTITALIC, DISPMETHOD, BSTR, DISPPROPERTY, Color,
    OLE_ENABLEDEFAULTBOOL, dispid, FONTNAME, IDispatch,
    OLE_XPOS_CONTAINER, GUID, OLE_XPOS_HIMETRIC
)


class LoadPictureConstants(IntFlag):
    Default = 0
    Monochrome = 1
    VgaColor = 2
    Color = 4


class OLE_TRISTATE(IntFlag):
    Unchecked = 0
    Checked = 1
    Gray = 2


__all__ = [
    'OLE_XSIZE_CONTAINER', 'OLE_YSIZE_PIXELS', 'OLE_HANDLE',
    'Default', 'FONTSTRIKETHROUGH', 'OLE_CANCELBOOL',
    'OLE_YSIZE_HIMETRIC', 'OLE_XSIZE_PIXELS', 'Library',
    'IFontEventsDisp', 'VgaColor', 'StdPicture', 'OLE_YPOS_PIXELS',
    'StdFont', 'Font', 'OLE_XPOS_PIXELS', 'OLE_YSIZE_CONTAINER',
    'Unchecked', 'Monochrome', 'FONTBOLD', 'FONTUNDERSCORE',
    'Picture', 'FONTSIZE', 'OLE_XSIZE_HIMETRIC', 'OLE_OPTEXCLUSIVE',
    'OLE_YPOS_HIMETRIC', 'IPictureDisp', 'IPicture', 'FontEvents',
    'typelib_path', 'FONTITALIC', 'Gray', 'OLE_COLOR', 'Color',
    'OLE_ENABLEDEFAULTBOOL', 'Checked', 'LoadPictureConstants',
    'OLE_TRISTATE', 'OLE_YPOS_CONTAINER', 'FONTNAME', 'IFont',
    'OLE_XPOS_CONTAINER', 'IFontDisp', 'OLE_XPOS_HIMETRIC'
]

